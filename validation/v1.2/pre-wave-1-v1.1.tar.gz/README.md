# Entity Resolution Solution Atlas

A project-agnostic, Markdown-first knowledge base for deciding how to design, evaluate and improve Entity Resolution systems. It expands alternatives rather than prescribing one architecture.

**This is not an ER implementation.** There are no matching algorithms, trained models, processed datasets or production application here. Documentation validation tools check the knowledge repository only.

The repository-local normative contract is [SCOPE.md](SCOPE.md), [AGENTS.md](AGENTS.md), [SCHEMA.md](SCHEMA.md) and the [evidence policy](references/evidence-policy.md); no external master instruction is required.

## Start with a question
1. Record the actual project's identity semantics, sources, label availability, data quality, error costs, access constraints and lifecycle in [project intake](guides/project-intake.md).
2. Retrieve progressively: the compact [L0 catalog](CATALOG.md) finds candidate IDs by domain or applicability tag; the [L1 domain indexes](indexes/domains/) compare alternatives; full [L2 cards](#pilot-scope-and-retrieval-layers) explain mechanisms and failures; [L3 deep dives](deep-dives/selection-and-calibration.md) resolve remaining theory. Do not load the whole repository.
3. Compare a simple baseline and applicable alternatives; inspect [architecture dimensions](taxonomy/architecture-dimensions.md) and [module contracts](taxonomy/module-contracts.md). Use the [coverage matrix](guides/decision-coverage-matrix.md) to judge whether a question is Covered, Partial, Missing or Deferred.
4. Use hypotheses and evaluations to propose a falsifiable project-specific experiment. Do not treat a theoretical mechanism as a measured improvement.

For future agents, [AGENTS.md](AGENTS.md) defines selective retrieval and uncertainty-preserving recommendations.

## Navigation
| Location | Purpose |
|---|---|
| [Scope](SCOPE.md) | Repository-local purpose, object types, evidence, retrieval and validation contract |
| [Taxonomy](taxonomy/overview.md) | Fourteen coherent knowledge domains and boundaries |
| [L0 catalog](CATALOG.md) / [L1 domain indexes](indexes/domains/) | Generated compact discovery and per-domain comparison navigation |
| `decisions/` | Identity, candidate, evidence, scoring, resolution and master-selection questions |
| `solutions/` | Blocking, evidence states, scoring, assignment/clustering policies, temporal identity, survivorship, reference construction |
| `architectures/` | Six reusable, composable reference patterns |
| `research/hypotheses/` | Untested frequency and contextual-reliability experiments |
| `evaluation/` | Candidate, pairwise/calibration, entity-level and retrieval blind-spot evaluation |
| [Guides](guides/project-intake.md) | Intake, comparisons, conceptual scenarios, coverage matrix, expansion, quality and content review |
| [Deep dive](deep-dives/selection-and-calibration.md) | Selection bias, dependence and probability interpretation |
| `templates/` | The five primary card formats |
| [References](references/bibliography.md) | Verified sources, evidence scope and immutable-input hashes |
| [Agent-utility benchmark](validation/agent-utility/) | Frozen scenarios, rubric, brokered harness and adapter; results are evaluation artifacts, not retrieval knowledge |
| `dev_docs/` | Six historical design discussions, unchanged |
| `tools/` | Optional documentation lint/catalog tooling, not ER code |

## Pilot scope and retrieval layers
The validated v1 pilot contained **21 knowledge objects** (6 architecture cards plus 3 decisions, 7 solutions, 2 hypotheses, 3 evaluations). The v1.1 iteration adds **10 connected cards** across identity semantics (2), resolution policy (4), master construction (2) and ground truth/evaluation (2), for **31 objects**: 6 decisions, 13 solutions, 6 architectures, 2 hypotheses and 4 evaluations. All IDs from v1 are unchanged; generated L0 and 14 L1 indexes replaced the monolithic catalog.

All fourteen domains have maps, but most method families outside candidate/evidence/interpretable scoring, resolution policy and reference construction remain unexpanded. Taxonomy mentions are not completed Solution Cards. [Reconciliation](guides/design-reconciliation.md) explains changes from the drafts; [opportunities](research/opportunities-index.md) preserves useful unexpanded ideas; the [coverage matrix](guides/decision-coverage-matrix.md) records Covered/Partial/Missing/Deferred per decision.

The [three scenario stress tests](guides/scenario-stress-tests.md) are conceptual walkthroughs, **not empirical benchmarks**. The frozen [AU-v1 benchmark](validation/agent-utility/) now has 33 validated scored responses across paired v1/v1.1 and no-Atlas runs. Its [per-dimension findings](validation/agent-utility/results/COMPARISON-2026-10-13.md) are mixed, with specific improvements and a v1.1 identity/assignment regression; they do not establish universal superiority. See the [quality review](guides/quality-review.md) for limitations. Stop at the validated v1.1 scope for user review; the [expansion plan](guides/expansion-plan.md) is a sequencing proposal, not authorization to mass-generate the encyclopedia.

## Evidence and contribution rules
- Follow [SCHEMA.md](SCHEMA.md) and the [evidence policy](references/evidence-policy.md); the [content rubric](guides/content-review-rubric.md) separates substantive review from structural lint.
- Preserve source bytes, stable IDs and one canonical location per object.
- Cite checked literature, specify its context, and label hypotheses/unknowns explicitly.
- Distinguish score semantics, decision actions and entity representations; keep hard prerequisites, compatibility roles, interaction risks and conditional exclusions explicit.
- Maintain the manifests, generated L0/L1 navigation, typed relations and [change log](guides/change-log.md).
- Run documented [repository checks](tools/README.md) and perform conceptual review before declaring coverage complete.

This Atlas is a knowledge resource, not an instruction to change a production system. No reference pattern is universally optimal.
