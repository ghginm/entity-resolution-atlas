# Atlas change log

Dates use UTC for build events; source-ledger access dates may use the agent's local timezone.

## 2026-10-13 — Audit and foundation
- Reviewed all six historical documents, recorded SHA-256 baselines and left `dev_docs/` unchanged.
- Initialized a local Git repository on `main`; no remote, commit or push was requested.
- Synthesized fourteen domain maps, four architecture dimensions and conceptual module contracts; resolved AR/ARC naming in favor of AR.
- Added schema, five templates, README/agent workflow, intake/comparison guides, preserved opportunities and a bounded expansion plan.
- Verified a small bibliography with full-text/abstract-only limitations; excluded failed exploratory references from authorized citations.
- Authored documentation-only catalog/lint tooling and exercised sixteen unit tests successfully.
- Prepared three hypothetical scenario walkthroughs for final card/route review. They are not measured ER benchmarks.

## 2026-10-13 — Validated pilot and review gate
- Completed six Architecture Cards and fifteen additional cards: three decisions, seven solutions, two hypotheses and three evaluations.
- Added a justified deep dive on candidate selection, evidence dependence and probability calibration; built the selective catalog from 64–76-word discovery summaries.
- Read and reviewed all pilot cards and the deep dive, corrected redundant reciprocal metadata, terminology and independent scenario navigation, and standardized equation delimiters.
- Citation/Source-block verification passed for twenty-three documents; full repository lint reported zero errors/warnings, and nineteen tooling unit tests passed.
- Verified all six historical hashes, all object/relationship/path targets, catalog freshness, and three scenario routes with two alternative configurations each.
- Stopped after the validated pilot and grouped expansion plan. No ER implementation, data processing, model training or empirical performance result was produced; no commit or push was made.

Detailed findings and remaining limitations: [quality review](quality-review.md); machine-readable check scope: [validation results](validation-results.json).

## 2026-10-13 — v1.1 decision coverage, composability, retrieval and benchmark
- Verified the v1 baseline before edits (21 objects, 19 tooling tests, zero-warning lint) and snapshotted it byte-for-byte; no original card, ID, path or historical input changed. The repository has no Git commit; the snapshot manifest is the frozen baseline.
- Authored ten connected cards from the approved v1.1 plan: identity semantics and temporal identity (DEC-01-001, SOL-01-001); resolution choice, partial assignment, connected components and constrained membership (DEC-08-001, SOL-08-002/003/004); master representation and provenance-preserving survivorship (DEC-09-001, SOL-09-001); independent entity-centric reference construction and retrieval blind-spot audit (SOL-10-001, EVAL-11-004). Total 31 objects.
- Added four scoped primary references (ledger IDs 11–14; full-text retrieved and section-scoped in research notes): bipartite matching, clustering-framework evaluation, data fusion, multifile partitioning.
- Documented prerequisites, compatibility roles, interaction risks and conditional exclusions in card prose; no mechanical `requires`/`conflicts_with` population and no rigid compatibility rules. One principled `requires` edge (SOL-08-004 → DEC-01-001).
- Retrieval scalability: generated compact L0 `CATALOG.md` plus fourteen per-domain L1 indexes (`indexes/domains/`) from stable frontmatter; tag-derived routes replaced the hand-coded problem table; `references/atlas-manifest.json` records current scope while `pilot-manifest.json` stays a verified historical subset.
- Self-containment: added repository-local [SCOPE.md](../SCOPE.md), [content rubric](content-review-rubric.md) and [decision coverage matrix](decision-coverage-matrix.md); AGENTS/SCHEMA/reconciliation no longer depend on the unavailable original master instruction.
- Validation split into structural checks (now 45 unit tests: sections, orphans, cycles, malformed metadata, freshness, warning-only length/keyword hints) and substantive review; frozen eight-scenario [agent-utility benchmark](../validation/agent-utility/) with blinded harness, trusted zero-tool Hermes-CLI adapter and independent evaluator pipeline.
- Executed real paired v1/v1.1 agent cohorts and independent blinded scoring; results, failures and disclosed limitations recorded in the [quality review](quality-review.md). No ER algorithm ran, no dataset processed, no empirical ER performance claim made; no Git commit or push performed.

## 2026-10-13 — Agent-utility scoring completed
- The chain finished at 15:05:57 UTC: 25 completed paired responses and eight no-Atlas responses scored through fresh openai-codex provider-default evaluator processes; seven paired transport failures remain unscored and retained. Earlier Sonnet billing failures remain historical records.
- Added a reproducible summary command that revalidates quotes, provenance and frozen caps before applying the predeclared first-completed selection rule. Published [dimension vectors, critical failures and limitations](../validation/agent-utility/results/COMPARISON-2026-10-13.md), without an aggregate winner.
- Recorded mixed findings: AU-02 blind-spot and AU-06 master distinctions improved; AU-03 v1.1 identity/assignment reasoning regressed. Updated v1.2 priorities without changing frozen scenarios, keys, rubric or corpus snapshots.
- Disclosed unpinned evaluator model/version, unattested sampling, transport failures, cross-cohort AU-05 and later noninterleaved no-Atlas runs. Model judgments are not empirical ER results or a universal Atlas improvement claim.
