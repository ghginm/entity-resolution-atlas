# Knowledge catalog

L0: find an ID or tag, then retrieve its domain L1 index and canonical card. Tags and summaries are discovery clues, not recommendations or compatibility guarantees.

**31 knowledge objects:** 6 decision, 13 solution, 6 architecture, 2 hypothesis, 4 evaluation.

## Objects

| ID | Title | Type | Domain | Concise applicability | Canonical path |
|---|---|---|---|---|---|
| [AR-01](architectures/linear-modular.md) | Linear/Modular Baseline | architecture | 02 | A sequential reference composition separates normalization, candidate generation, comparison evidence, scoring, decision policy, and entity construction through explicit artifacts. | `architectures/linear-modular.md` |
| [AR-02](architectures/recall-multi-pass.md) | Recall-Oriented Multi-Pass | architecture | 02 | Multiple retrieval passes propose overlapping candidate pairs, which are unioned, deduplicated, and scored under a declared downstream policy. | `architectures/recall-multi-pass.md` |
| [AR-03](architectures/precision-cascade.md) | Precision-First Adaptive Cascade | architecture | 02 | A cascade routes uncertain cases to progressively more costly evidence, scorers, or human review while allowing justified early decisions. | `architectures/precision-cascade.md` |
| [AR-04](architectures/parallel-ensemble.md) | Parallel Multi-Model/Ensemble | architecture | 02 | Several scorers examine shared or explicitly unioned candidates, then a fusion policy combines outputs or sends disagreements to review. | `architectures/parallel-ensemble.md` |
| [AR-05](architectures/collective-consistency.md) | Collective/Consistency-Aware Resolution | architecture | 02 | Resolution decisions are coupled when identity semantics impose cardinality, membership constraints, or useful relational dependencies. | `architectures/collective-consistency.md` |
| [AR-06](architectures/incremental-continuous.md) | Incremental/Continuous Entity Resolution | architecture | 02 | Versioned changes to observations, models, or policies trigger recomputation of affected candidates, evidence, decisions, and entity views instead of routinely restarting every… | `architectures/incremental-continuous.md` |
| [DEC-01-001](decisions/identity-semantics.md) | Define identity before choosing resolution | decision | 01 | Define the real-world object, granularity, namespace and time scope that a correct identity assertion denotes. | `decisions/identity-semantics.md` |
| [DEC-05-001](decisions/candidate-strategy.md) | Choose a candidate generation strategy | decision | 05 | Choose how to expose plausible record pairs to downstream comparison without exhausting the admissible pair space. | `decisions/candidate-strategy.md` |
| [DEC-06-001](decisions/comparison-evidence.md) | Design comparison evidence before choosing a scorer | decision | 06 | Choose how two records become interpretable comparison evidence, keeping value agreement, absence, validity, contradiction, and contextual reliability distinct. | `decisions/comparison-evidence.md` |
| [DEC-07-001](decisions/scoring-strategy.md) | How should candidate pairs be scored? | decision | 07 | Compare expert-weighted additive evidence, Fellegi–Sunter likelihood ratios, and supervised logistic regression without treating them as a mandatory progression. | `decisions/scoring-strategy.md` |
| [DEC-08-001](decisions/resolution-strategy.md) | Choosing the resolution output and membership policy | decision | 08 | Choose independent pair decisions, partial one-to-one assignment, accepted-link closure, or constrained entity membership from the task's identity and cardinality contract. | `decisions/resolution-strategy.md` |
| [DEC-09-001](decisions/master-representation.md) | Choose master representation and identity lifecycle | decision | 09 | Decide how resolved members become a persistent entity that consumers use: virtual membership views, consolidated golden records, or hybrid derived views with retained lineage. | `decisions/master-representation.md` |
| [EVAL-11-001](evaluation/candidate-recall.md) | Candidate recall and retrieval efficiency | evaluation | 11 | Measure whether candidate generation retains independently established true matches while reducing eligible comparisons. | `evaluation/candidate-recall.md` |
| [EVAL-11-002](evaluation/pairwise-calibration.md) | Pairwise discrimination and probability calibration | evaluation | 11 | Evaluate pairwise ranking, threshold decisions, and the reliability of claimed match probabilities as separate properties. | `evaluation/pairwise-calibration.md` |
| [EVAL-11-003](evaluation/entity-resolution-quality.md) | Final entity-resolution quality and error diagnostics | evaluation | 11 | Assess the final identity output rather than assuming pairwise scores determine entity quality. | `evaluation/entity-resolution-quality.md` |
| [EVAL-11-004](evaluation/retrieval-blind-spots.md) | Retrieval blind-spot audit and missed-pair estimation | evaluation | 11 | Estimate how many true matches candidate retrieval misses, rather than only measuring recall over already-emitted candidates. | `evaluation/retrieval-blind-spots.md` |
| [HYP-06-001](research/hypotheses/frequency-aware-evidence.md) | Frequency-aware agreement evidence under population shift | hypothesis | 06 | Test whether population-aware agreement evidence improves held-out matching recall at a fixed precision requirement compared with the same scorer using frequency-blind comparisons. | `research/hypotheses/frequency-aware-evidence.md` |
| [HYP-07-001](research/hypotheses/contextual-reliability.md) | Context-dependent attribute reliability without circular supervision | hypothesis | 07 | Test whether constrained source- and time-aware evidence weighting reduces held-out decision cost relative to a pooled scorer with the same candidates and comparisons. | `research/hypotheses/contextual-reliability.md` |
| [SOL-01-001](solutions/identity-semantics/temporal-identity.md) | Enduring identity with time-scoped evidence | solution | 01 | Maintain enduring entity identity while representing changing attributes as versioned, time-scoped observations rather than overwriting history. | `solutions/identity-semantics/temporal-identity.md` |
| [SOL-05-001](solutions/candidate-generation/exact-blocking.md) | Exact-key blocking | solution | 05 | Admit record pairs that share a declared blocking key, using equality on a single attribute or a composite of attributes. | `solutions/candidate-generation/exact-blocking.md` |
| [SOL-05-002](solutions/candidate-generation/multi-pass-blocking.md) | Multi-pass blocking and candidate union | solution | 05 | Combine candidate sets from distinct blocking or retrieval passes so that different attributes and representations can expose different matching pairs. | `solutions/candidate-generation/multi-pass-blocking.md` |
| [SOL-06-001](solutions/comparison-features/evidence-states.md) | Explicit comparison evidence states | solution | 06 | Represent field comparisons with explicit states and supporting context instead of treating all non-agreement as the same numeric value. | `solutions/comparison-features/evidence-states.md` |
| [SOL-07-001](solutions/matching-scoring/additive-soft-matching.md) | Additive soft matching | solution | 07 | Combine explicit comparison features through a baseline and signed evidence contributions rather than requiring every field to agree. | `solutions/matching-scoring/additive-soft-matching.md` |
| [SOL-07-002](solutions/matching-scoring/fellegi-sunter.md) | Fellegi–Sunter evidence weighting | solution | 07 | Compare the distribution of observed comparison evidence among true matches with its distribution among non-matches. | `solutions/matching-scoring/fellegi-sunter.md` |
| [SOL-07-003](solutions/matching-scoring/logistic-regression.md) | Logistic regression for pairwise matching | solution | 07 | Learn an interpretable conditional log-odds function from labeled comparison evidence and map it through the logistic link. | `solutions/matching-scoring/logistic-regression.md` |
| [SOL-08-001](solutions/decision-resolution/thresholds-abstention.md) | Thresholds, abstention, and review policies | solution | 08 | Convert pairwise scores into link, non-link, or deferred decisions using explicit losses, validated operating points, and review constraints. | `solutions/decision-resolution/thresholds-abstention.md` |
| [SOL-08-002](solutions/decision-resolution/one-to-one-assignment.md) | Partial one-to-one assignment for bipartite linkage | solution | 08 | Resolve competing cross-source candidates through a maximum-utility partial bipartite matching with at most one match at both endpoints and explicit unmatched alternatives. | `solutions/decision-resolution/one-to-one-assignment.md` |
| [SOL-08-003](solutions/decision-resolution/connected-components.md) | Connected components of accepted identity links | solution | 08 | Form a partition by closing accepted identity links under graph connectivity, including isolated records. | `solutions/decision-resolution/connected-components.md` |
| [SOL-08-004](solutions/decision-resolution/constrained-clustering.md) | Constrained entity partitioning with admissible membership | solution | 08 | Resolve records into entity clusters only when proposed merges satisfy audited must-link, cannot-link, source, entity-type, and time constraints. | `solutions/decision-resolution/constrained-clustering.md` |
| [SOL-09-001](solutions/master-records/provenance-survivorship.md) | Provenance-preserving attribute survivorship | solution | 09 | Derive consumer-facing master values from field-specific raw observations while preserving source, transformation, time and selection lineage for every chosen value. | `solutions/master-records/provenance-survivorship.md` |
| [SOL-10-001](solutions/ground-truth/independent-reference.md) | Independent entity-centric reference construction | solution | 10 | Build evaluation references that can expose identities missed by production retrieval rather than certifying only its candidates. | `solutions/ground-truth/independent-reference.md` |

## Domain L1 indexes

- [01 — Problem Formulation & Identity Semantics](indexes/domains/01.md)
- [02 — Pipeline Architecture & Orchestration](indexes/domains/02.md)
- [03 — Data Understanding & Integration](indexes/domains/03.md)
- [04 — Normalization & Enrichment](indexes/domains/04.md)
- [05 — Candidate Generation & Retrieval](indexes/domains/05.md)
- [06 — Comparison Features & Evidence Engineering](indexes/domains/06.md)
- [07 — Matching & Scoring](indexes/domains/07.md)
- [08 — Decision Policies & Entity Resolution](indexes/domains/08.md)
- [09 — Master Entity Construction & Maintenance](indexes/domains/09.md)
- [10 — Ground Truth & Labeling](indexes/domains/10.md)
- [11 — Evaluation & Diagnostics](indexes/domains/11.md)
- [12 — Experimentation & Research Methods](indexes/domains/12.md)
- [13 — Scalability & Execution](indexes/domains/13.md)
- [14 — Explainability, Governance & Monitoring](indexes/domains/14.md)

## Tag entry points

| Tag | Domain routes to matching objects |
|---|---|
| `assignment` | [02](indexes/domains/02.md#tag-assignment), [08](indexes/domains/08.md#tag-assignment), [11](indexes/domains/11.md#tag-assignment) |
| `asymmetric-costs` | [02](indexes/domains/02.md#tag-asymmetric-costs), [07](indexes/domains/07.md#tag-asymmetric-costs), [08](indexes/domains/08.md#tag-asymmetric-costs), [11](indexes/domains/11.md#tag-asymmetric-costs) |
| `batch` | [02](indexes/domains/02.md#tag-batch), [08](indexes/domains/08.md#tag-batch), [09](indexes/domains/09.md#tag-batch) |
| `blocking` | [05](indexes/domains/05.md#tag-blocking), [07](indexes/domains/07.md#tag-blocking), [11](indexes/domains/11.md#tag-blocking) |
| `calibration` | [02](indexes/domains/02.md#tag-calibration), [07](indexes/domains/07.md#tag-calibration), [11](indexes/domains/11.md#tag-calibration) |
| `candidate-generation` | [02](indexes/domains/02.md#tag-candidate-generation), [05](indexes/domains/05.md#tag-candidate-generation), [11](indexes/domains/11.md#tag-candidate-generation) |
| `clean` | [05](indexes/domains/05.md#tag-clean) |
| `clustering` | [02](indexes/domains/02.md#tag-clustering), [08](indexes/domains/08.md#tag-clustering), [11](indexes/domains/11.md#tag-clustering) |
| `collective` | [02](indexes/domains/02.md#tag-collective), [11](indexes/domains/11.md#tag-collective) |
| `compute-intensive` | [02](indexes/domains/02.md#tag-compute-intensive) |
| `conflicting` | [06](indexes/domains/06.md#tag-conflicting), [09](indexes/domains/09.md#tag-conflicting) |
| `constraints` | [01](indexes/domains/01.md#tag-constraints), [02](indexes/domains/02.md#tag-constraints), [08](indexes/domains/08.md#tag-constraints), [11](indexes/domains/11.md#tag-constraints) |
| `entity-agnostic` | [01](indexes/domains/01.md#tag-entity-agnostic), [02](indexes/domains/02.md#tag-entity-agnostic), [05](indexes/domains/05.md#tag-entity-agnostic), [06](indexes/domains/06.md#tag-entity-agnostic), [07](indexes/domains/07.md#tag-entity-agnostic), [08](indexes/domains/08.md#tag-entity-agnostic), [09](indexes/domains/09.md#tag-entity-agnostic), [10](indexes/domains/10.md#tag-entity-agnostic), [11](indexes/domains/11.md#tag-entity-agnostic) |
| `evaluation` | [02](indexes/domains/02.md#tag-evaluation), [05](indexes/domains/05.md#tag-evaluation), [07](indexes/domains/07.md#tag-evaluation), [10](indexes/domains/10.md#tag-evaluation), [11](indexes/domains/11.md#tag-evaluation) |
| `evidence-engineering` | [06](indexes/domains/06.md#tag-evidence-engineering), [07](indexes/domains/07.md#tag-evidence-engineering) |
| `experimentation` | [06](indexes/domains/06.md#tag-experimentation), [07](indexes/domains/07.md#tag-experimentation), [11](indexes/domains/11.md#tag-experimentation) |
| `few-labels` | [07](indexes/domains/07.md#tag-few-labels), [10](indexes/domains/10.md#tag-few-labels) |
| `frequency-aware` | [06](indexes/domains/06.md#tag-frequency-aware) |
| `governance` | [01](indexes/domains/01.md#tag-governance), [02](indexes/domains/02.md#tag-governance), [09](indexes/domains/09.md#tag-governance), [10](indexes/domains/10.md#tag-governance) |
| `high-precision` | [02](indexes/domains/02.md#tag-high-precision), [06](indexes/domains/06.md#tag-high-precision), [08](indexes/domains/08.md#tag-high-precision) |
| `high-recall` | [02](indexes/domains/02.md#tag-high-recall), [05](indexes/domains/05.md#tag-high-recall), [08](indexes/domains/08.md#tag-high-recall), [11](indexes/domains/11.md#tag-high-recall) |
| `human-review` | [02](indexes/domains/02.md#tag-human-review), [08](indexes/domains/08.md#tag-human-review), [10](indexes/domains/10.md#tag-human-review), [11](indexes/domains/11.md#tag-human-review) |
| `identifiers` | [01](indexes/domains/01.md#tag-identifiers), [05](indexes/domains/05.md#tag-identifiers) |
| `incremental` | [01](indexes/domains/01.md#tag-incremental), [02](indexes/domains/02.md#tag-incremental), [08](indexes/domains/08.md#tag-incremental), [09](indexes/domains/09.md#tag-incremental) |
| `interpretable` | [02](indexes/domains/02.md#tag-interpretable), [05](indexes/domains/05.md#tag-interpretable), [06](indexes/domains/06.md#tag-interpretable), [07](indexes/domains/07.md#tag-interpretable), [08](indexes/domains/08.md#tag-interpretable), [09](indexes/domains/09.md#tag-interpretable) |
| `low-cost` | [05](indexes/domains/05.md#tag-low-cost), [07](indexes/domains/07.md#tag-low-cost) |
| `missingness` | [06](indexes/domains/06.md#tag-missingness), [07](indexes/domains/07.md#tag-missingness), [09](indexes/domains/09.md#tag-missingness) |
| `monitoring` | [02](indexes/domains/02.md#tag-monitoring) |
| `multi-pass` | [02](indexes/domains/02.md#tag-multi-pass), [05](indexes/domains/05.md#tag-multi-pass), [11](indexes/domains/11.md#tag-multi-pass) |
| `multilingual` | [02](indexes/domains/02.md#tag-multilingual) |
| `multiscript` | [02](indexes/domains/02.md#tag-multiscript) |
| `no-labels` | [07](indexes/domains/07.md#tag-no-labels) |
| `noisy` | [02](indexes/domains/02.md#tag-noisy), [05](indexes/domains/05.md#tag-noisy) |
| `pairwise` | [02](indexes/domains/02.md#tag-pairwise), [06](indexes/domains/06.md#tag-pairwise), [07](indexes/domains/07.md#tag-pairwise), [08](indexes/domains/08.md#tag-pairwise), [11](indexes/domains/11.md#tag-pairwise) |
| `provenance` | [01](indexes/domains/01.md#tag-provenance), [02](indexes/domains/02.md#tag-provenance), [05](indexes/domains/05.md#tag-provenance), [06](indexes/domains/06.md#tag-provenance), [09](indexes/domains/09.md#tag-provenance), [10](indexes/domains/10.md#tag-provenance) |
| `rich-labels` | [07](indexes/domains/07.md#tag-rich-labels) |
| `source-aware` | [01](indexes/domains/01.md#tag-source-aware), [05](indexes/domains/05.md#tag-source-aware), [06](indexes/domains/06.md#tag-source-aware), [07](indexes/domains/07.md#tag-source-aware), [08](indexes/domains/08.md#tag-source-aware), [09](indexes/domains/09.md#tag-source-aware), [10](indexes/domains/10.md#tag-source-aware) |
| `sparse` | [02](indexes/domains/02.md#tag-sparse) |
| `streaming` | [02](indexes/domains/02.md#tag-streaming) |
| `uncertainty` | [01](indexes/domains/01.md#tag-uncertainty), [02](indexes/domains/02.md#tag-uncertainty), [06](indexes/domains/06.md#tag-uncertainty), [07](indexes/domains/07.md#tag-uncertainty), [08](indexes/domains/08.md#tag-uncertainty), [10](indexes/domains/10.md#tag-uncertainty), [11](indexes/domains/11.md#tag-uncertainty) |

Generated by `python tools/atlas_docs.py catalog`; edit card metadata, not derived indexes.
