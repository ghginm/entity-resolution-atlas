# Entity Resolution Solution Atlas

A project-agnostic, Markdown-first knowledge base for deciding how to design, evaluate and improve Entity Resolution systems. It expands alternatives rather than prescribing one architecture.

**This is not an ER implementation.** There are no matching algorithms, trained models, processed datasets or production application here. Documentation validation tools check the knowledge repository only.

The repository-local normative contract is [SCOPE.md](SCOPE.md), [AGENTS.md](AGENTS.md), [SCHEMA.md](SCHEMA.md) and the [evidence policy](references/evidence-policy.md); no external master instruction is required.

## Start with a question
1. Record the actual project's identity semantics, sources, label availability, data quality, error costs, access constraints and lifecycle in [project intake](guides/project-intake.md).
2. Retrieve progressively: the compact [L0 catalog](CATALOG.md) finds candidate IDs by domain or applicability tag; the [L1 domain indexes](indexes/domains/) compare alternatives; full [L2 cards](#pilot-scope-and-retrieval-layers) explain mechanisms and failures; [L3 deep dives](deep-dives/selection-and-calibration.md) resolve remaining theory. Do not load the whole repository.
3. Compare a simple baseline and applicable alternatives; inspect [architecture dimensions](taxonomy/architecture-dimensions.md) and [module contracts](taxonomy/module-contracts.md). Use the [coverage matrix](guides/decision-coverage-matrix.md) to judge whether a question is Covered, Partial, Missing or Deferred.
4. Use hypotheses and evaluations to propose a falsifiable project-specific experiment. Do not treat a theoretical mechanism as a measured improvement.

For future agents, [AGENTS.md](AGENTS.md) defines selective retrieval and uncertainty-preserving recommendations.

## Navigation
| Location | Purpose |
|---|---|
| [Scope](SCOPE.md) | Repository-local purpose, object types, evidence, retrieval and validation contract |
| [Taxonomy](taxonomy/overview.md) | Fourteen coherent knowledge domains and boundaries |
| [L0 catalog](CATALOG.md) / [L1 domain indexes](indexes/domains/) | Generated compact discovery and per-domain comparison navigation |
| `decisions/` | Identity, modularity, candidates, evidence, scoring, resolution/rule composition, masters, acquisition and experiments |
| `solutions/` | Retrieval/evidence/scoring, resolution/rules, temporal identity, survivorship, reference acquisition, controlled comparisons and versioned artifact pipelines |
| `architectures/` | Six reusable, composable reference patterns |
| `research/hypotheses/` | Untested frequency and contextual-reliability experiments |
| `evaluation/` | Candidate, pairwise/calibration, entity, blind-spot, incomplete-reference and synthetic/metamorphic behavior evaluation |
| [Guides](guides/project-intake.md) | Intake, comparisons, conceptual scenarios, coverage matrix, expansion, quality and content review |
| [Selection deep dive](deep-dives/selection-and-calibration.md) / [incomplete-reference estimation](deep-dives/incomplete-reference-estimation.md) | Optional L3 probability, bounds, denominator and variance details |
| `templates/` | The five primary card formats |
| [References](references/bibliography.md) | Verified sources, evidence scope and immutable-input hashes |
| [Agent-utility benchmark](validation/agent-utility/) | Frozen scenarios, rubric, brokered harness and adapter; results are evaluation artifacts, not retrieval knowledge |
| `dev_docs/` | Six historical design discussions, unchanged |
| `tools/` | Optional documentation lint/catalog tooling, not ER code |

## Pilot scope and retrieval layers
The validated v1 pilot contained **21 knowledge objects** (6 architecture cards plus 3 decisions, 7 solutions, 2 hypotheses, 3 evaluations). The v1.1 iteration adds **10 connected cards** across identity semantics (2), resolution policy (4), master construction (2) and ground truth/evaluation (2), for **31 objects**: 6 decisions, 13 solutions, 6 architectures, 2 hypotheses and 4 evaluations. All IDs from v1 are unchanged; generated L0 and 14 L1 indexes replaced the monolithic catalog.

**Current snapshot: v1.2 Wave 3, 52 objects** — 11 decisions, 27 solutions, 6 architectures, 2 hypotheses and 6 evaluations. Wave 1 covers acquisition, incomplete truth and experiments; Wave 2 covers modularity, rules and artifact lifecycle; Wave 3 adds seven connected cards on name representations, string/identifier evidence, approximate retrieval, source-conditioned pooling and richer comparators. Existing scoring and graph owners are deepened rather than duplicated. The [tracker](guides/v1.2-expansion-tracker.md), [content review](guides/v1.2-wave-3-content-review.md) and [Wave 4 handoff](guides/v1.2-wave-3-handoff.md) distinguish implemented content/checks from remaining work and evidence gaps. Five primary types, fourteen domains and six architecture IDs are unchanged.

For absent/poor labels, start with [acquisition choice](decisions/ground-truth-acquisition.md) and [what incomplete truth can establish](evaluation/incomplete-reference-quality.md). For a controlled change, use [experiment design](decisions/experiment-design.md) and the [plan template](guides/experiment-plan-template.md). [Behavioral tests](guides/er-behavioral-testing.md) help with contract regressions, not real-world accuracy claims. Retrieve only applicable alternatives and optional L3 details.

For a rule-heavy refactor, start with [composition choice](decisions/rule-composition.md), then the relevant ordered/table alternative and [refactor witnesses](guides/rule-policy-refactoring.md). For engineering boundaries, start with [modularity choice](decisions/pipeline-modularity.md); only follow [artifact reuse](solutions/architecture/versioned-artifact-runs.md), the [run manifest](guides/run-manifest-template.md), [stage contracts](taxonomy/module-contracts.md) or [decision provenance](guides/decision-provenance.md) when the actual change needs them. A framework, workflow service and every role as a separate stage are not prerequisites.

For lossy name cleaning, start with [representation choice](decisions/name-representation.md), then the selected [comparator](solutions/comparison-features/string-comparators.md) or [identifier semantics](solutions/comparison-features/identifier-namespaces.md). For blocking, use [candidate choice](decisions/candidate-strategy.md) and the selected [approximate mechanism](solutions/candidate-generation/approximate-blocking.md). For source heterogeneity, compare [pooling](solutions/matching-scoring/source-aware-reliability.md) against a global scorer before considering a [richer model](solutions/matching-scoring/learned-neural-comparators.md). For unexpected giant entities, follow [closure fragility and repair](solutions/decision-resolution/connected-components.md#graph-fragility-selective-verification-and-repair), not a blanket “remove bridges” policy.

All fourteen domains have maps, but specialist algorithms, physical scaling, monitoring and governance remain partially covered or deferred. Taxonomy mentions and bounded model-role comparisons are not complete implementation recipes. [Reconciliation](guides/design-reconciliation.md) explains changes from the drafts; [opportunities](research/opportunities-index.md) preserves useful unexpanded ideas; the [coverage matrix](guides/decision-coverage-matrix.md) records Covered/Partial/Missing/Deferred per decision.

The [three scenario stress tests](guides/scenario-stress-tests.md) are conceptual walkthroughs, **not empirical benchmarks**. The frozen [AU-v1 benchmark](validation/agent-utility/) has 33 validated scored responses about its historical v1/v1.1/no-Atlas corpora. Its [findings](validation/agent-utility/results/COMPARISON-2026-10-13.md) are mixed; see [historical quality review](guides/quality-review.md) for limitations. They are **not results for Wave 1–3 additions**. No new agent-utility, ER or engineering experiment was run in these expansion waves. Wave 3's four delegated authoring tasks all failed with HTTP 402; the parent authored the content and records author-only critique, not independent approval. The explicit v1.2+ authorization and subsequent continuation supersede the old review gate; later algorithmic, operational and agent-utility work remains tracked, not completed by documentation checks.

## Evidence and contribution rules
- Follow [SCHEMA.md](SCHEMA.md) and the [evidence policy](references/evidence-policy.md); the [content rubric](guides/content-review-rubric.md) separates substantive review from structural lint.
- Preserve source bytes, stable IDs and one canonical location per object.
- Cite checked literature, specify its context, and label hypotheses/unknowns explicitly.
- Distinguish score semantics, decision actions and entity representations; keep hard prerequisites, compatibility roles, interaction risks and conditional exclusions explicit.
- Maintain the manifests, generated L0/L1 navigation, typed relations and [change log](guides/change-log.md).
- Run documented [repository checks](tools/README.md) and perform conceptual review before declaring coverage complete.

This Atlas is a knowledge resource, not an instruction to change a production system. No reference pattern is universally optimal.
