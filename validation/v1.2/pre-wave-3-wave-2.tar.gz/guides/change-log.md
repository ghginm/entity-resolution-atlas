# Atlas change log

Dates use UTC for build events; source-ledger access dates may use the agent's local timezone.

## 2026-10-13 — Audit and foundation
- Reviewed all six historical documents, recorded SHA-256 baselines and left `dev_docs/` unchanged.
- Initialized a local Git repository on `main`; no remote, commit or push was requested.
- Synthesized fourteen domain maps, four architecture dimensions and conceptual module contracts; resolved AR/ARC naming in favor of AR.
- Added schema, five templates, README/agent workflow, intake/comparison guides, preserved opportunities and a bounded expansion plan.
- Verified a small bibliography with full-text/abstract-only limitations; excluded failed exploratory references from authorized citations.
- Authored documentation-only catalog/lint tooling and exercised sixteen unit tests successfully.
- Prepared three hypothetical scenario walkthroughs for final card/route review. They are not measured ER benchmarks.

## 2026-10-13 — Validated pilot and review gate
- Completed six Architecture Cards and fifteen additional cards: three decisions, seven solutions, two hypotheses and three evaluations.
- Added a justified deep dive on candidate selection, evidence dependence and probability calibration; built the selective catalog from 64–76-word discovery summaries.
- Read and reviewed all pilot cards and the deep dive, corrected redundant reciprocal metadata, terminology and independent scenario navigation, and standardized equation delimiters.
- Citation/Source-block verification passed for twenty-three documents; full repository lint reported zero errors/warnings, and nineteen tooling unit tests passed.
- Verified all six historical hashes, all object/relationship/path targets, catalog freshness, and three scenario routes with two alternative configurations each.
- Stopped after the validated pilot and grouped expansion plan. No ER implementation, data processing, model training or empirical performance result was produced; no commit or push was made.

Detailed findings and remaining limitations: [quality review](quality-review.md); machine-readable check scope: [validation results](validation-results.json).

## 2026-10-13 — v1.1 decision coverage, composability, retrieval and benchmark
- Verified the v1 baseline before edits (21 objects, 19 tooling tests, zero-warning lint) and snapshotted it byte-for-byte; no original card, ID, path or historical input changed. The repository has no Git commit; the snapshot manifest is the frozen baseline.
- Authored ten connected cards from the approved v1.1 plan: identity semantics and temporal identity (DEC-01-001, SOL-01-001); resolution choice, partial assignment, connected components and constrained membership (DEC-08-001, SOL-08-002/003/004); master representation and provenance-preserving survivorship (DEC-09-001, SOL-09-001); independent entity-centric reference construction and retrieval blind-spot audit (SOL-10-001, EVAL-11-004). Total 31 objects.
- Added four scoped primary references (ledger IDs 11–14; full-text retrieved and section-scoped in research notes): bipartite matching, clustering-framework evaluation, data fusion, multifile partitioning.
- Documented prerequisites, compatibility roles, interaction risks and conditional exclusions in card prose; no mechanical `requires`/`conflicts_with` population and no rigid compatibility rules. One principled `requires` edge (SOL-08-004 → DEC-01-001).
- Retrieval scalability: generated compact L0 `CATALOG.md` plus fourteen per-domain L1 indexes (`indexes/domains/`) from stable frontmatter; tag-derived routes replaced the hand-coded problem table; `references/atlas-manifest.json` records current scope while `pilot-manifest.json` stays a verified historical subset.
- Self-containment: added repository-local [SCOPE.md](../SCOPE.md), [content rubric](content-review-rubric.md) and [decision coverage matrix](decision-coverage-matrix.md); AGENTS/SCHEMA/reconciliation no longer depend on the unavailable original master instruction.
- Validation split into structural checks (now 45 unit tests: sections, orphans, cycles, malformed metadata, freshness, warning-only length/keyword hints) and substantive review; frozen eight-scenario [agent-utility benchmark](../validation/agent-utility/) with blinded harness, trusted zero-tool Hermes-CLI adapter and independent evaluator pipeline.
- Executed real paired v1/v1.1 agent cohorts and independent blinded scoring; results, failures and disclosed limitations recorded in the [quality review](quality-review.md). No ER algorithm ran, no dataset processed, no empirical ER performance claim made; no Git commit or push performed.

## 2026-10-13 — Agent-utility scoring completed
- The chain finished at 15:05:57 UTC: 25 completed paired responses and eight no-Atlas responses scored through fresh openai-codex provider-default evaluator processes; seven paired transport failures remain unscored and retained. Earlier Sonnet billing failures remain historical records.
- Added a reproducible summary command that revalidates quotes, provenance and frozen caps before applying the predeclared first-completed selection rule. Published [dimension vectors, critical failures and limitations](../validation/agent-utility/results/COMPARISON-2026-10-13.md), without an aggregate winner.
- Recorded mixed findings: AU-02 blind-spot and AU-06 master distinctions improved; AU-03 v1.1 identity/assignment reasoning regressed. Updated v1.2 priorities without changing frozen scenarios, keys, rubric or corpus snapshots.
- Disclosed unpinned evaluator model/version, unattested sampling, transport failures, cross-cohort AU-05 and later noninterleaved no-Atlas runs. Model judgments are not empirical ER results or a universal Atlas improvement claim.

## 2026-10-14 — v1.2 Wave 0–1 and resumable Wave 2 handoff
- Assessed the actual 31-card corpus, relevant contracts/coverage, evidence ledger and evaluation tooling before authoring. Verified all six historical inputs; no archive packaging repair was needed. Saved a durable pre-wave snapshot and hashes because the repository still has no Git HEAD.
- Recorded the comprehensive authorization and [all-wave tracker](v1.2-expansion-tracker.md); superseded the old v1.1 stop gate without changing five object types, fourteen domains, six architecture IDs, historical IDs/paths or benchmark restrictions. This session stops at the requested Wave 0–1 boundary.
- Added eight connected cards: acquisition DEC-10-001; probability/active/weak acquisition SOL-10-002/003/004; incomplete-reference EVAL-11-005; experimental design DEC-12-001 and controlled comparison SOL-12-001; behavioral EVAL-11-006. Current inventory: 39 cards (8 DEC, 17 SOL, 6 AR, 2 HYP, 6 EVAL).
- Deepened SOL-10-001 and EVAL-11-001 through EVAL-11-004 rather than replacing their theory. Added an optional estimation deep dive, supporting experiment template and behavioral-testing guide; kept exactly five primary templates. Updated current coverage, source ledger/provenance, README/agent contracts, domain routes and generated L0/L1 navigation.
- Verified eight primary/official additions, ledger IDs 15–22, with selected support scope and limitations. Source 4 v1 was rechecked for the entity-balanced B-cubed/with-replacement distinction. No external empirical gains were generalized to ER.
- Two distinct scientific critique roles produced retained reports. Fixed the blocking confusion between production selection and independent evaluation inclusion, plus same-universe denominators, source-specific metric aggregation, foreign-record versus distinct-identity counts, rare-zero inversion/stopping, conditional splits, uncertainty ownership, acquisition comparator scope and theory-count caveats. [Review and dispositions](v1.2-wave-1-content-review.md) records author closure, not independent benchmark validation.
- Added a mandatory explicit evaluation-route lint gate with observed failing/passing regression test. Documentation suite now has 46 tests; benchmark infrastructure remains 39 tests. Advisory length warnings and the pre-existing AR-05 keyword hint remain disclosed; no validation rule was relaxed. Exact final outputs: [validation report](../validation/v1.2/wave-1-validation.json).
- Preserved all existing AU-v1 files/results, immutable inputs and original pilot mapping. No ER experiment, model training, dataset processing, new model cohort, production changes, commit or push. The finite algebra checks are documentation sanity checks, not ER results.
- Saved [handoff](v1.2-wave-1-handoff.md) with exact Wave 2 entry point, minimal prerequisite reads, commands, changed-file evidence and remaining architecture/rule/MLOps work; subsequent sessions should continue the tracker rather than reconstruct the task.

## 2026-10-14 — v1.2 Wave 2: engineering and rule-policy families
- Continued the user's “Proceed” from the validated Wave 1 handoff. Saved pre-wave hashes and an allowlisted knowledge snapshot; existing Git tree remains uncommitted/untracked. All previous IDs/paths, five types, fourteen domains and six architectures remain.
- Added six cards: DEC-02-001 modularity; SOL-02-001 replaceable-stage pipelines; SOL-02-002 versioned artifact runs; DEC-08-002 rule composition; SOL-08-005 ordered policies; SOL-08-006 declarative tables. Current inventory: 45 cards (10 DEC, 21 SOL, 6 AR, 2 HYP, 6 EVAL).
- Expanded thirteen conceptual stage roles in the existing module-contract owner, not mandatory deployment stages. Deepened AR-06 with current-state/event-history alternatives, dependency closure, temporal revisions/tombstones, stable IDs/redirects/splits and downstream consistency; retained deeper operational work for Wave 4.
- Added supporting rule-refactor, realized-run manifest and decision-provenance guides. Extended EVAL-11-006 for engineering substitution/replay rather than creating another evaluation family; linked existing AR-01 and threshold/resolution owners. Updated current manifest, domain routes, generated L0/L1, coverage, README and maintenance entry points.
- Added six scoped references, ledger 23–28: deliberately versioned DMN 1.5; DVC declared-dependency caching; W3C PROV; pinned MLflow registry; author-maintained rules/event-sourcing essays. Direct HTTPS recovered configured extraction limitations; failed exploratory Parnas retrieval was not admitted. No ER performance or framework-ranking result was inferred.
- Retained two distinct content critiques. Integrating-author remediation closed 13 findings (four major, nine minor): compound Collect/Priority restrictions, required-guard unknown/error propagation, engineering-cost linkage, committed-state idempotency, diagnostic trust, history-qualified replay, previously unstored candidates, authorized rollback, scoped atomicity, optional calibration, task-order learning and duplicate exposition. This is not independent post-remediation approval.
- Exercised 46 documentation and 39 benchmark-infrastructure tests; post-remediation full lint passed with advisory warnings retained. Exact final checks, citation verification, freeze/corpus and protected-file comparisons are in [Wave 2 validation](../validation/v1.2/wave-2-validation.json). No validation rule changed or relaxed.
- Preserved immutable historical inputs, original pilot mapping, all existing AU-v1 files/results and earlier-wave artifacts. No ER or engineering experiment, test-fixture runner, training, data processing, new agent cohort, production changes, commit or push.
- Saved the [Wave 3 handoff](v1.2-wave-2-handoff.md), linked from the tracker; next work starts with the bounded evidence/representation slice and proceeds through existing Wave 3 rows, not another repository-wide assessment.
