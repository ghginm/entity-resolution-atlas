"""Tests for documentation checking, never ER examples or fabricated results."""
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest

import atlas_docs


class ParsingTests(unittest.TestCase):
    def test_frontmatter_mapping(self):
        data, body = atlas_docs.frontmatter('---\nid: "SOL-07-001"\ndomain: "07"\n---\n# Body\n')
        self.assertEqual(data['domain'], '07')
        self.assertEqual(body, '# Body\n')

    def test_missing_frontmatter(self):
        with self.assertRaises(ValueError):
            atlas_docs.frontmatter('# No metadata\n')

    def test_duplicate_key_rejected(self):
        with self.assertRaisesRegex(ValueError, 'duplicate YAML key'):
            atlas_docs.frontmatter('---\nid: first\nid: second\n---\nBody\n')

    def test_scalar_frontmatter_rejected(self):
        with self.assertRaises(ValueError):
            atlas_docs.frontmatter('---\nhello\n---\nBody\n')

    def test_heading_ids_handle_duplicates_and_fences(self):
        self.assertEqual(atlas_docs.heading_ids('# A title\n## A title\n```md\n# Not a heading\n```\n'), {'a-title', 'a-title-1'})

    def test_citations_exclude_numeric_navigation(self):
        self.assertEqual(atlas_docs.citation_ids('[08](domain.md) Claim.[1][2]'), {1, 2})


class RepositoryTests(unittest.TestCase):
    def setUp(self):
        scratch = Path(os.environ.get('TMPDIR', '/home/ghgin/.hermes/cache/scratch'))
        scratch.mkdir(parents=True, exist_ok=True)
        self.tmp = tempfile.TemporaryDirectory(prefix='atlas-docs-test-', dir=scratch)
        self.root = Path(self.tmp.name)
        (self.root/'docs').mkdir()
        self.path = self.root/'docs/start.md'
        self.path.write_text('# Start\n')
        self.target = self.root/'docs/target.md'
        self.target.write_text('# Real heading\n')

    def tearDown(self):
        self.tmp.cleanup()

    def test_relative_link_and_anchor(self):
        self.assertEqual(atlas_docs.validate_links(self.path,'[x](target.md#real-heading)',self.root),[])

    def test_broken_path(self):
        errors = atlas_docs.validate_links(self.path,'[x](absent.md)',self.root)
        self.assertIn('broken path', errors[0])

    def test_broken_anchor(self):
        errors = atlas_docs.validate_links(self.path,'[x](target.md#not-present)',self.root)
        self.assertIn('broken anchor',errors[0])

    def test_external_and_code_examples_ignored(self):
        text='[x](https://example.invalid/thing)\n```md\n[x](absent.md)\n```\n'
        self.assertEqual(atlas_docs.validate_links(self.path,text,self.root),[])

    def test_escape_rejected(self):
        errors=atlas_docs.validate_links(self.path,'[x](../../outside.md)',self.root)
        self.assertIn('escapes repository',errors[0])

    def fixture(self):
        for directory in ('decisions','solutions','evaluation','references','dev_docs'):
            (self.root/directory).mkdir(exist_ok=True)
        source=self.root/'dev_docs/original.txt'
        source.write_bytes(b'Original\r\n')
        (self.root/'references/dev-docs-sha256.json').write_text(json.dumps({'dev_docs/original.txt':hashlib.sha256(source.read_bytes()).hexdigest()}))
        (self.root/'references/retrieval-status.json').write_text(json.dumps({'verified_full_text':[1],'verified_metadata_only':[],'verified_publisher_abstract':[],'unverified_unused':[2]}))
        (self.root/'references/source-ledger.json').write_text(json.dumps({'sources':[{'id':1,'url':'https://example.invalid/verified'},{'id':2,'url':'https://example.invalid/unverified'}]}))
        (self.root/'SCHEMA.md').write_text('`interpretable`\n')
        cards=[
            ('decisions/question.md','DEC-07-001','decision','07',{'complements':['SOL-07-001'],'evaluated_by':['EVAL-11-001']}),
            ('solutions/method.md','SOL-07-001','solution','07',{'addresses':['DEC-07-001'],'evaluated_by':['EVAL-11-001']}),
            ('evaluation/measure.md','EVAL-11-001','evaluation','11',{'tests':['SOL-07-001'],'complements':['DEC-07-001']}),
        ]
        for name,ident,typ,domain,relations in cards:
            data={'id':ident,'type':typ,'title':'QA fixture','domain':domain,'summary':' '.join(['discovery']*60),'tags':['interpretable'],'maturity':'established','evidence':'theoretically-motivated','relations':relations}
            fm='\n'.join(f'{k}: {json.dumps(v)}' for k,v in data.items())
            (self.root/name).write_text('---\n'+fm+'\n---\n# QA fixture\n\n'+' '.join(['content']*410)+'\n')

    def test_valid_nonpilot_fixture(self):
        self.fixture()
        self.assertEqual(atlas_docs.lint(self.root,pilot=False)['errors'],[])

    def test_numeric_navigation_does_not_need_sources(self):
        self.fixture()
        path=self.root/'solutions/method.md'
        path.write_text(path.read_text()+'\n[08](../docs/target.md)\n')
        self.assertEqual(atlas_docs.lint(self.root,pilot=False)['errors'],[])

    def test_changed_input_rejected(self):
        self.fixture()
        (self.root/'dev_docs/original.txt').write_bytes(b'Changed\n')
        self.assertTrue(any('immutable input' in error for error in atlas_docs.lint(self.root,pilot=False)['errors']))

    def test_invalid_relation_rejected(self):
        self.fixture()
        path=self.root/'solutions/method.md'
        path.write_text(path.read_text().replace('DEC-07-001','DEC-07-099'))
        self.assertTrue(any('unresolved relation' in error for error in atlas_docs.lint(self.root,pilot=False)['errors']))

    def test_unverified_citation_rejected(self):
        self.fixture()
        path=self.root/'solutions/method.md'
        path.write_text(path.read_text()+'\nUnsupported.[2]\n\n## Sources\n[2] URL\n')
        self.assertTrue(any('unverified/unknown source' in error for error in atlas_docs.lint(self.root,pilot=False)['errors']))

    def test_citation_block_mismatch_rejected(self):
        self.fixture()
        path=self.root/'solutions/method.md'
        path.write_text(path.read_text()+'\nClaim.[1]\n\n## Sources\n[2] URL\n')
        self.assertTrue(any('cited/source-block IDs differ' in error for error in atlas_docs.lint(self.root,pilot=False)['errors']))

    def test_duplicate_id_rejected(self):
        self.fixture()
        original=self.root/'solutions/method.md'
        (self.root/'solutions/copy.md').write_text(original.read_text())
        self.assertTrue(any('duplicate ID' in error for error in atlas_docs.lint(self.root,pilot=False)['errors']))

    def test_redundant_reciprocal_metadata_rejected(self):
        self.fixture()
        path=self.root/'solutions/method.md'
        data, body=atlas_docs.frontmatter(path.read_text())
        data['relations']['complements']=['DEC-07-001']
        fm='\n'.join(f'{k}: {json.dumps(v)}' for k,v in data.items())
        path.write_text('---\n'+fm+'\n---\n'+body)
        self.assertTrue(any('redundant reciprocal' in error for error in atlas_docs.lint(self.root,pilot=False)['errors']))


if __name__ == '__main__':
    unittest.main()
