#!/usr/bin/env python3
"""Catalog and lint the Markdown Atlas; no entity-resolution functionality."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
from urllib.parse import unquote, urlsplit

import yaml

ROOT = Path(__file__).resolve().parents[1]
CARD_DIRS = ('decisions', 'solutions', 'architectures', 'research/hypotheses', 'evaluation')
TYPES = {'decision': 'DEC', 'solution': 'SOL', 'architecture': 'AR', 'hypothesis': 'HYP', 'evaluation': 'EVAL'}
RELATIONS = {'addresses', 'alternative_to', 'complements', 'requires', 'conflicts_with', 'used_by', 'tests', 'evaluated_by'}
MATURITIES = {'established', 'context-dependent', 'experimental', 'speculative'}
EVIDENCE = {'theoretically-motivated', 'supported-by-external-literature', 'empirically-validated-in-specific-context', 'unknown-or-insufficient'}
ID_RE = re.compile(r'\b(?:AR-\d{2}|(?:DEC|SOL|HYP|EVAL)-\d{2}-\d{3})\b')
LINK_RE = re.compile(r'\[[^\]\n]+\]\(([^)\n]+)\)')


class UniqueLoader(yaml.SafeLoader):
    """Reject repeated YAML keys rather than silently accepting the last one."""


def unique_mapping(loader, node, deep=False):
    result = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        if key in result:
            raise ValueError(f'duplicate YAML key: {key}')
        result[key] = loader.construct_object(value_node, deep=deep)
    return result


UniqueLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, unique_mapping)


def frontmatter(text):
    match = re.match(r'\A---\r?\n(.*?)\r?\n---\r?\n(.*)\Z', text, re.S)
    if not match:
        raise ValueError('missing YAML frontmatter')
    data = yaml.load(match.group(1), Loader=UniqueLoader)
    if not isinstance(data, dict):
        raise ValueError('frontmatter must be a mapping')
    return data, match.group(2)


def prose_without_fences(text):
    return re.sub(r'(?ms)^(```|~~~).*?^\1[^\n]*\n?', '', text)


def citation_ids(text):
    """Numeric inline navigation labels are links, not source citations."""
    return set(map(int, re.findall(r'\[(\d+)\](?!\s*\()', text)))


def heading_ids(text):
    slugs = set()
    counts = Counter()
    for title in re.findall(r'^#{1,6}\s+(.+?)\s*#*\s*$', prose_without_fences(text), re.M):
        title = re.sub(r'\[([^]]+)\]\([^)]+\)', r'\1', title)
        slug = re.sub(r'[^\w\- ]', '', title.lower(), flags=re.UNICODE).replace(' ', '-')
        suffix = counts[slug]
        counts[slug] += 1
        slugs.add(slug if suffix == 0 else f'{slug}-{suffix}')
    slugs.update(re.findall(r'<a\s+(?:id|name)=["\']([^"\']+)', text))
    return slugs


def validate_links(path, text, root):
    errors = []
    for dest in LINK_RE.findall(prose_without_fences(text)):
        dest = dest.strip().split(' "', 1)[0].strip('<>')
        parsed = urlsplit(dest)
        if parsed.scheme or parsed.netloc:
            continue
        target = (path.parent / unquote(parsed.path)).resolve() if parsed.path else path.resolve()
        if not target.is_relative_to(root.resolve()):
            errors.append(f'link escapes repository: {dest}')
        elif not target.exists():
            errors.append(f'broken path: {dest}')
        elif parsed.fragment and target.suffix == '.md':
            if unquote(parsed.fragment) not in heading_ids(target.read_text(encoding='utf-8')):
                errors.append(f'broken anchor: {dest}')
    return errors


def cards(root):
    output = []
    for directory in CARD_DIRS:
        for path in sorted((root / directory).rglob('*.md')):
            data, body = frontmatter(path.read_text(encoding='utf-8'))
            output.append((path, data, body))
    return output


def catalog_text(root):
    objects = cards(root)
    domains = json.loads((root / 'taxonomy/domain-registry.json').read_text())
    counts = Counter(data['type'] for _, data, _ in objects)
    total = len(objects)
    lines = [
        '# Knowledge catalog', '',
        'Selective retrieval: first find a decision, then read linked alternatives, architectures, hypotheses and evaluations. Tags are applicability clues, not recommendations or empirical guarantees.', '',
        f'**{total} knowledge objects:** {counts["architecture"]} architectures plus {total-counts["architecture"]} non-architecture pilot cards ({counts["decision"]} decisions, {counts["solution"]} solutions, {counts["hypothesis"]} hypotheses, {counts["evaluation"]} evaluations).', '',
        '## Browse by problem characteristics', '',
        '| Characteristic | Useful entry points | Important caveat |',
        '|---|---|---|',
        '| No/few labels | DEC-07-001 → additive / Fellegi–Sunter; HYP-07-001 | Unsupervised estimation is assumption-dependent; independent evaluation still needs labels |',
        '| Rich representative labels | DEC-07-001 → logistic; EVAL-11-002 | Hard-negative sampling and source shift can invalidate probabilities |',
        '| Clean / reliable identifiers | DEC-05-001 → exact blocking; DEC-06-001 | Audit namespaces, reuse and validity before trusting equality |',
        '| Noisy / sparse / conflicting | DEC-06-001 → evidence states; SOL-05-002 | Missing is unknown, not contradictory or matching by default |',
        '| Large scale / tight compute | AR-02 versus AR-03; AR-06; EVAL-11-001 | Caps and cheap exits can lose difficult true matches |',
        '| Person / organization / address / identifiers | Domains 01, 03, 04 → DEC-06-001 | Type semantics and relationship versus identity precede features |',
        '| Multilingual / multiscript | Domain 04 → DEC-05-001, DEC-06-001; scenario B | Detailed language-specific method cards remain unexpanded |',
        '| Precision / recall / asymmetric error costs | AR-02 versus AR-03; SOL-08-001; EVAL-11-003 | Pairwise error costs are not automatically entity-merge costs |',
        '| Explainability | SOL-07-001, SOL-07-002, SOL-07-003 | Interpretable contributions need assumptions; they are not causal explanations |',
        '| Batch / incremental / streaming | AR-01 versus AR-06; domain 13 | New, changed and deleted records may invalidate a dependency closure |',
        '| Privacy / federated / human review | Domain 14; SOL-08-001; AR-06 | Privacy/security solution coverage is a gap, not deployment guidance |', '',
        'IDs in this navigation table are linked in the domain index below. For a practical route use [project intake](guides/project-intake.md), [comparison guide](guides/compare-and-experiment.md), and [three conceptual scenarios](guides/scenario-stress-tests.md).', '',
        '## Domain index', '',
    ]
    for domain, info in sorted(domains.items()):
        lines += [f'### {domain} — {info["title"]}', '', f'[Domain map]({info["path"]})', '']
        selected = [(p, d) for p, d, _ in objects if d['domain'] == domain]
        if not selected:
            lines += ['Taxonomy coverage only; no standalone pilot cards. See [expansion plan](guides/expansion-plan.md).', '']
            continue
        lines += ['| ID / title | Type | Domain | L1 discovery summary | Tags |', '|---|---|---|---|---|']
        for path, data in sorted(selected, key=lambda pair: pair[1]['id']):
            rel = path.relative_to(root).as_posix()
            summary = data['summary'].replace('\n', ' ').replace('|', '\\|')
            title = data['title'].replace('|', '\\|')
            tags = ', '.join(data['tags'])
            lines.append(f'| [{data["id"]} — {title}]({rel}) | {data["type"]} | {domain} | {summary} | {tags} |')
        lines.append('')
    lines += [
        '## Coverage and evidence', '',
        'The catalog indexes completed objects, not every method mentioned in the fourteen domain maps. Unexpanded families remain in [research opportunities](research/opportunities-index.md) and the [expansion plan](guides/expansion-plan.md). Maturity and evidence are separate metadata fields; hypotheses have no observed Atlas outcomes. Source-specific support and its limitations appear in each card.', '',
        'Generated from frontmatter by `python tools/atlas_docs.py catalog`. Maintain the cards and regenerate this index rather than editing derived summaries independently.', '',
    ]
    return '\n'.join(lines)


def lint(root, pilot=True):
    errors, warnings = [], []
    try:
        objects = cards(root)
    except (ValueError, yaml.YAMLError) as exc:
        return {'errors': [str(exc)], 'warnings': [], 'counts': {}}
    by_id = {}
    schema_text = (root / 'SCHEMA.md').read_text()
    allowed_tags = set(re.findall(r'`([a-z][a-z0-9-]+)`', schema_text))
    required = {'id', 'type', 'title', 'domain', 'summary', 'tags', 'maturity', 'evidence', 'relations'}
    stats = []
    for path, data, body in objects:
        rel = path.relative_to(root).as_posix()
        missing = required - data.keys()
        if missing:
            errors.append(f'{rel}: missing fields {sorted(missing)}')
            continue
        ident = data['id']
        if ident in by_id:
            errors.append(f'{rel}: duplicate ID {ident}')
        by_id[ident] = (path, data)
        typ, domain = data['type'], data['domain']
        if typ not in TYPES:
            errors.append(f'{rel}: unknown type {typ}')
        elif typ == 'architecture':
            if not re.fullmatch(r'AR-\d{2}', str(ident)) or domain != '02':
                errors.append(f'{rel}: invalid architecture ID/domain')
        elif not re.fullmatch(rf'{TYPES[typ]}-{re.escape(str(domain))}-\d{{3}}', str(ident)):
            errors.append(f'{rel}: ID does not match type/domain')
        if not isinstance(domain, str) or not re.fullmatch(r'0[1-9]|1[0-4]', domain):
            errors.append(f'{rel}: domain must be quoted 01–14')
        if data['maturity'] not in MATURITIES or data['evidence'] not in EVIDENCE:
            errors.append(f'{rel}: invalid maturity/evidence')
        if not isinstance(data['tags'], list) or any(t not in allowed_tags for t in data['tags']):
            errors.append(f'{rel}: unknown or malformed tags {data["tags"]}')
        if not isinstance(data['relations'], dict):
            errors.append(f'{rel}: relations must be mapping')
        if not isinstance(data['summary'], str) or not data['summary'].strip():
            errors.append(f'{rel}: discovery summary must be nonempty string')
        else:
            words = len(data['summary'].split())
            if not 50 <= words <= 100:
                warnings.append(f'{rel}: discovery summary {words} words (target 50–100)')
        words = len(re.findall(r'\S+', body.split('\n## Sources', 1)[0]))
        if words < 400:
            errors.append(f'{rel}: substantive body only {words} words')
        elif words > 1000:
            warnings.append(f'{rel}: body {words} words; consider justified deep dive')
        if typ == 'hypothesis' and not re.search('falsif', body, re.I):
            errors.append(f'{rel}: hypothesis lacks explicit falsification content')
        stats.append({'id':ident,'path':rel,'body_words':words})
    for ident, (path, data) in by_id.items():
        if not isinstance(data.get('relations'), dict):
            continue
        count = 0
        for relation, targets in data['relations'].items():
            if relation not in RELATIONS or not isinstance(targets, list):
                errors.append(f'{ident}: invalid relation {relation}')
                continue
            count += len(targets)
            for target in targets:
                if target not in by_id:
                    errors.append(f'{ident}: unresolved relation {relation} → {target}')
                    continue
                target_type = by_id[target][1]['type']
                expected = {'addresses':'decision','used_by':'architecture','evaluated_by':'evaluation'}.get(relation)
                if expected and target_type != expected:
                    errors.append(f'{ident}: wrong {relation} target type {target}')
                if relation == 'addresses' and data['type'] != 'solution':
                    errors.append(f'{ident}: addresses must originate in solution')
                if relation == 'used_by' and data['type'] == 'architecture':
                    errors.append(f'{ident}: used_by direction reversed')
                if relation == 'tests' and target_type not in {'solution','architecture'}:
                    errors.append(f'{ident}: tests target must be solution/architecture')
                if target == ident:
                    errors.append(f'{ident}: self relation')
        if count < 2:
            errors.append(f'{ident}: fewer than two typed outbound relationships')
    for ident, (_, data) in by_id.items():
        if not isinstance(data.get('relations'), dict):
            continue
        for relation in ('complements', 'alternative_to', 'conflicts_with'):
            targets = data['relations'].get(relation, [])
            if not isinstance(targets, list):
                continue
            for target in targets:
                if target not in by_id or not isinstance(by_id[target][1].get('relations'), dict):
                    continue
                reverse = by_id[target][1]['relations'].get(relation, [])
                if isinstance(reverse, list) and ident in reverse and ident < target:
                    errors.append(f'{ident}: redundant reciprocal {relation} with {target}')
    status = json.loads((root / 'references/retrieval-status.json').read_text())
    allowed_sources = set(status['verified_full_text'] + status['verified_metadata_only'] + status['verified_publisher_abstract'])
    ledger = json.loads((root / 'references/source-ledger.json').read_text())
    known_sources = {s['id'] for s in ledger['sources']}
    for path in sorted(root.rglob('*.md')):
        if '.git' in path.parts:
            continue
        text = path.read_text(encoding='utf-8')
        rel = path.relative_to(root).as_posix()
        for error in validate_links(path, text, root):
            errors.append(f'{rel}: {error}')
        if rel.startswith('templates/'):
            continue
        for ident in set(ID_RE.findall(prose_without_fences(text))):
            if ident not in by_id:
                errors.append(f'{rel}: unresolved prose ID {ident}')
        parts = re.split(r'^## Sources\s*$', text, maxsplit=1, flags=re.M)
        prose_ids = citation_ids(parts[0])
        for source in prose_ids:
            if source not in known_sources or source not in allowed_sources:
                errors.append(f'{rel}: unverified/unknown source [{source}]')
        if prose_ids and len(parts) != 2:
            errors.append(f'{rel}: citations but no rendered Sources block')
        if len(parts) == 2:
            rendered_ids = set(map(int, re.findall(r'^\[(\d+)\]', parts[1], re.M)))
            if prose_ids != rendered_ids and rel != 'references/bibliography.md':
                errors.append(f'{rel}: cited/source-block IDs differ {sorted(prose_ids)} vs {sorted(rendered_ids)}')
    hashes = json.loads((root / 'references/dev-docs-sha256.json').read_text())
    for name, expected_hash in hashes.items():
        path = root / name
        if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest() != expected_hash:
            errors.append(f'{name}: immutable input missing or changed')
    actual_inputs = {p.relative_to(root).as_posix() for p in (root/'dev_docs').iterdir() if p.is_file()}
    if actual_inputs != set(hashes):
        errors.append('immutable input inventory differs from original baseline')
    counts = Counter(data['type'] for _, data, _ in objects)
    if pilot:
        expected_counts = {'architecture':6,'decision':3,'solution':7,'hypothesis':2,'evaluation':3}
        if dict(counts) != expected_counts:
            errors.append(f'pilot counts mismatch: {dict(counts)} expected {expected_counts}')
        manifest = json.loads((root / 'references/pilot-manifest.json').read_text())
        if set(manifest) != set(by_id):
            errors.append('pilot manifest IDs differ from actual cards')
        for ident, expected_path in manifest.items():
            if ident in by_id and by_id[ident][0].relative_to(root).as_posix() != expected_path:
                errors.append(f'{ident}: path differs from manifest')
        domains = json.loads((root / 'taxonomy/domain-registry.json').read_text())
        if set(domains) != {f'{i:02d}' for i in range(1,15)}:
            errors.append('domain registry does not represent exactly 01–14')
        for domain in domains.values():
            if not (root/domain['path']).exists():
                errors.append(f'missing domain summary {domain["path"]}')
        templates = {p.stem for p in (root/'templates').glob('*.md')}
        if templates != set(TYPES):
            errors.append('five card templates missing or unexpected')
        if not (root/'CATALOG.md').exists():
            errors.append('catalog missing')
        elif (root/'CATALOG.md').read_text() != catalog_text(root):
            errors.append('catalog stale; regenerate from frontmatter')
    return {'errors':errors,'warnings':warnings,'counts':dict(counts),'immutable_inputs':len(hashes),'card_statistics':stats}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['catalog','lint'])
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--no-pilot', action='store_true', help='Disable initial pilot shape/count gate')
    args = parser.parse_args()
    if args.action == 'catalog':
        target = args.root/'CATALOG.md'
        target.write_text(catalog_text(args.root), encoding='utf-8')
        print(f'Generated {target}')
        return 0
    result = lint(args.root, pilot=not args.no_pilot)
    print(json.dumps(result,indent=2,ensure_ascii=False))
    return 1 if result['errors'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
