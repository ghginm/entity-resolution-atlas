# Documentation validation tools

These optional tools lint Markdown metadata/navigation and regenerate a derived catalog. They do **not** implement Entity Resolution, execute an ER experiment, process entity data or validate algorithm performance.

## Requirements and commands
Python 3.10+ and the pinned YAML parser in `requirements.txt`. Use an isolated environment; no global package install is necessary.

```sh
python3 -m venv .venv-qa
.venv-qa/bin/python -m pip install -r tools/requirements.txt
.venv-qa/bin/python -m unittest discover -s tools -p 'test_*.py'
.venv-qa/bin/python tools/atlas_docs.py catalog
.venv-qa/bin/python tools/atlas_docs.py lint
```

For this initial build, the exercised environment lives in the agent scratch cache rather than inside the repository. A future user can use the commands above. QA fixtures use the configured scratch directory, never real ER datasets.

## What is checked
- Required YAML fields, duplicate keys and IDs, quoted domains, ID/type/domain consistency, approved tags, maturity/evidence classes.
- Typed relationship targets and direction for addresses/used_by/evaluated_by/tests; self-links, redundant reciprocal metadata and underconnected cards.
- Ordinary relative Markdown paths and heading anchors; prose IDs; repository-contained navigation.
- Citation IDs against the ledger and verified retrieval status; citation/Source-block agreement.
- Original `dev_docs/` byte hashes and exact input inventory.
- Initial shape: fourteen domains, six architectures, fifteen non-architecture cards, five templates, manifest agreement and exact catalog freshness.
- Card body/discovery-summary word counts as a depth signal, not a semantic completeness proof.

Use `lint --no-pilot` only after an approved expansion changes initial counts; it still checks metadata, references, links and source preservation. Change the expected pilot gate deliberately rather than using it to hide a missing card.

## What is not proved
A passing lint cannot establish scientific truth, adequate citations for every claim, meaningful mechanisms, valid sampling assumptions, experiment power, composability or useful recommendations. It does not fetch external URLs and cannot prove them permanently available. A human/agent must review conceptual requirements, source scope and the [scenario routes](../guides/scenario-stress-tests.md). [Quality review](../guides/quality-review.md) records that separate assessment.

Citation rendering uses the source-ledger helper available to the initial agent; the resulting Markdown Sources blocks and JSON ledger are portable. A future editor can preserve the same ledger numbering and generate equivalent blocks without requiring Hermes.
