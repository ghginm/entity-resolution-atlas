# Knowledge catalog

Selective retrieval: first find a decision, then read linked alternatives, architectures, hypotheses and evaluations. Tags are applicability clues, not recommendations or empirical guarantees.

**21 knowledge objects:** 6 architectures plus 15 non-architecture pilot cards (3 decisions, 7 solutions, 2 hypotheses, 3 evaluations).

## Browse by problem characteristics

| Characteristic | Useful entry points | Important caveat |
|---|---|---|
| No/few labels | DEC-07-001 → additive / Fellegi–Sunter; HYP-07-001 | Unsupervised estimation is assumption-dependent; independent evaluation still needs labels |
| Rich representative labels | DEC-07-001 → logistic; EVAL-11-002 | Hard-negative sampling and source shift can invalidate probabilities |
| Clean / reliable identifiers | DEC-05-001 → exact blocking; DEC-06-001 | Audit namespaces, reuse and validity before trusting equality |
| Noisy / sparse / conflicting | DEC-06-001 → evidence states; SOL-05-002 | Missing is unknown, not contradictory or matching by default |
| Large scale / tight compute | AR-02 versus AR-03; AR-06; EVAL-11-001 | Caps and cheap exits can lose difficult true matches |
| Person / organization / address / identifiers | Domains 01, 03, 04 → DEC-06-001 | Type semantics and relationship versus identity precede features |
| Multilingual / multiscript | Domain 04 → DEC-05-001, DEC-06-001; scenario B | Detailed language-specific method cards remain unexpanded |
| Precision / recall / asymmetric error costs | AR-02 versus AR-03; SOL-08-001; EVAL-11-003 | Pairwise error costs are not automatically entity-merge costs |
| Explainability | SOL-07-001, SOL-07-002, SOL-07-003 | Interpretable contributions need assumptions; they are not causal explanations |
| Batch / incremental / streaming | AR-01 versus AR-06; domain 13 | New, changed and deleted records may invalidate a dependency closure |
| Privacy / federated / human review | Domain 14; SOL-08-001; AR-06 | Privacy/security solution coverage is a gap, not deployment guidance |

IDs in this navigation table are linked in the domain index below. For a practical route use [project intake](guides/project-intake.md), [comparison guide](guides/compare-and-experiment.md), and [three conceptual scenarios](guides/scenario-stress-tests.md).

## Domain index

### 01 — Problem Formulation & Identity Semantics

[Domain map](taxonomy/domains/01-problem-identity.md)

Taxonomy coverage only; no standalone pilot cards. See [expansion plan](guides/expansion-plan.md).

### 02 — Pipeline Architecture & Orchestration

[Domain map](taxonomy/domains/02-architecture-orchestration.md)

| ID / title | Type | Domain | L1 discovery summary | Tags |
|---|---|---|---|---|
| [AR-01 — Linear/Modular Baseline](architectures/linear-modular.md) | architecture | 02 | A sequential reference composition separates normalization, candidate generation, comparison evidence, scoring, decision policy, and entity construction through explicit artifacts. It supports controlled component replacement without choosing a mandatory matching algorithm or resolution strategy. Use it when traceable experiments and understandable interfaces matter. Identity semantics, candidate scope, and score interpretation must be specified first; simplicity does not remove candidate omissions, calibration problems, or downstream merge risks. | entity-agnostic, interpretable, batch, pairwise, provenance, evaluation |
| [AR-02 — Recall-Oriented Multi-Pass](architectures/recall-multi-pass.md) | architecture | 02 | Multiple retrieval passes propose overlapping candidate pairs, which are unioned, deduplicated, and scored under a declared downstream policy. The pattern targets missed matches caused by heterogeneous names, identifiers, scripts, or sparse attributes without dictating a scorer. It requires complementary retrieval evidence and explicit eligibility rules. Candidate coverage can increase before pruning, but workload, selection bias, and false-positive exposure can also grow; pass value must be assessed marginally rather than by pass count. | entity-agnostic, high-recall, noisy, sparse, multilingual, multiscript, candidate-generation, multi-pass, provenance |
| [AR-03 — Precision-First Adaptive Cascade](architectures/precision-cascade.md) | architecture | 02 | A cascade routes uncertain cases to progressively more costly evidence, scorers, or human review while allowing justified early decisions. It targets asymmetric false-merge costs and uneven case difficulty, not a universal ordering of models. Reliable early evidence, explicit routing units, and reversible dispositions are prerequisites. Compute savings depend on how often cases can safely exit; downstream distribution shift and irreversible early mistakes can erase the benefit, so route-specific quality and end-to-end costs must be tested together. | entity-agnostic, high-precision, asymmetric-costs, uncertainty, human-review, provenance, evaluation |
| [AR-04 — Parallel Multi-Model/Ensemble](architectures/parallel-ensemble.md) | architecture | 02 | Several scorers examine shared or explicitly unioned candidates, then a fusion policy combines outputs or sends disagreements to review. The pattern seeks complementary evidence and error behavior rather than assuming more models are better. It requires compatible candidate keys, declared score meanings, and leakage-safe training when fusion is learned. Costs include multiple inference paths, calibration, and monitoring; correlated errors, incomparable scores, and silently missing branch outputs can undermine both accuracy and interpretability. | entity-agnostic, pairwise, calibration, uncertainty, compute-intensive, human-review, evaluation |
| [AR-05 — Collective/Consistency-Aware Resolution](architectures/collective-consistency.md) | architecture | 02 | Resolution decisions are coupled when identity semantics impose cardinality, membership constraints, or useful relational dependencies. The pattern covers one-to-one assignment with unmatched outcomes, constrained clustering, and genuinely collective relational inference without treating them as equivalent. It requires justified constraints and score semantics compatible with the resolution objective. Joint decisions may prevent locally plausible conflicts, but incorrect constraints or propagated evidence errors can harm whole groups; a graph representation and iterative inference are not mandatory. | entity-agnostic, assignment, clustering, collective, constraints, provenance, uncertainty, evaluation |
| [AR-06 — Incremental/Continuous Entity Resolution](architectures/incremental-continuous.md) | architecture | 02 | Versioned changes to observations, models, or policies trigger recomputation of affected candidates, evidence, decisions, and entity views instead of routinely restarting every stage. The lifecycle pattern can wrap linear, multi-pass, cascaded, ensemble, or consistency-aware matching. It requires explicit event semantics, dependency tracking, stable identity handling, and reversible updates. Locality may lower update cost, but deletions, long-range dependencies, drift, and accumulated historical mistakes can force wider repair or replay; full recomputation is a comparator, not ground truth. | entity-agnostic, incremental, streaming, provenance, governance, monitoring, constraints, evaluation |

### 03 — Data Understanding & Integration

[Domain map](taxonomy/domains/03-data-integration.md)

Taxonomy coverage only; no standalone pilot cards. See [expansion plan](guides/expansion-plan.md).

### 04 — Normalization & Enrichment

[Domain map](taxonomy/domains/04-normalization-enrichment.md)

Taxonomy coverage only; no standalone pilot cards. See [expansion plan](guides/expansion-plan.md).

### 05 — Candidate Generation & Retrieval

[Domain map](taxonomy/domains/05-candidate-retrieval.md)

| ID / title | Type | Domain | L1 discovery summary | Tags |
|---|---|---|---|---|
| [DEC-05-001 — Choose a candidate generation strategy](decisions/candidate-strategy.md) | decision | 05 | Choose how to expose plausible record pairs to downstream comparison without exhausting the admissible pair space. Compare exact keys, complementary passes, and unexpanded approximate retrieval families using coverage, skew, cost, and source compatibility. Requires explicit identity semantics, permitted source pairs, and a way to investigate missed matches. Candidate admission is not a match decision; budgets and filtering can undo the coverage benefits of broader retrieval. | candidate-generation, blocking, high-recall, low-cost, source-aware, evaluation, entity-agnostic |
| [SOL-05-001 — Exact-key blocking](solutions/candidate-generation/exact-blocking.md) | solution | 05 | Admit record pairs that share a declared blocking key, using equality on a single attribute or a composite of attributes. This creates an interpretable candidate baseline when key values are available, stable, and comparable across sources. Requires explicit normalization, missing-value handling, and identifier semantics. The main risks are complete exclusion after key errors and candidate explosion from common values; equality proposes comparison, not identity. | candidate-generation, blocking, interpretable, low-cost, clean, identifiers, entity-agnostic |
| [SOL-05-002 — Multi-pass blocking and candidate union](solutions/candidate-generation/multi-pass-blocking.md) | solution | 05 | Combine candidate sets from distinct blocking or retrieval passes so that different attributes and representations can expose different matching pairs. Requires stable pair identity, pass provenance, explicit eligibility rules, and evaluation beyond the original candidate set. An uncapped union preserves prior pair coverage, but overlapping passes add work without necessarily adding matches. Global caps, routing, or filtering can break that guarantee and change the downstream evidence distribution. | candidate-generation, blocking, multi-pass, high-recall, noisy, source-aware, provenance, evaluation |

### 06 — Comparison Features & Evidence Engineering

[Domain map](taxonomy/domains/06-comparison-evidence.md)

| ID / title | Type | Domain | L1 discovery summary | Tags |
|---|---|---|---|---|
| [DEC-06-001 — Design comparison evidence before choosing a scorer](decisions/comparison-evidence.md) | decision | 06 | Choose how two records become interpretable comparison evidence, keeping value agreement, absence, validity, contradiction, and contextual reliability distinct. Requires aligned attribute semantics, observation provenance, and declared comparison scope. Compare a compact state-based baseline with richer attribute, frequency, temporal, and representation features. More features can expose useful variation but also duplicate the same observation or encode source shortcuts; weighting and final action remain separate downstream decisions. | evidence-engineering, missingness, source-aware, frequency-aware, interpretable, uncertainty, entity-agnostic |
| [HYP-06-001 — Frequency-aware agreement evidence under population shift](research/hypotheses/frequency-aware-evidence.md) | hypothesis | 06 | Test whether population-aware agreement evidence improves held-out matching recall at a fixed precision requirement compared with the same scorer using frequency-blind comparisons. The mechanism is established likelihood-ratio reasoning, not a novelty claim or observed Atlas result. A valid experiment needs independently labeled entities, leakage-safe frequency estimation, unchanged candidates and policies, and predeclared practical effect and cost limits. Rare errors, copied values, sparse estimates, and population shifts may erase gains or increase false merges. | experimentation, frequency-aware, evidence-engineering, pairwise, uncertainty, high-precision, entity-agnostic |
| [SOL-06-001 — Explicit comparison evidence states](solutions/comparison-features/evidence-states.md) | solution | 06 | Represent field comparisons with explicit states and supporting context instead of treating all non-agreement as the same numeric value. Separate observed agreement, partial agreement, disagreement, missingness, invalidity, and semantic incomparability. Requires attribute-specific comparison rules and provenance; strong contradictions additionally require credible incompatible observations. The representation supports interpretable scoring and review, but does not prescribe evidence weights, guarantee independence, or make missing values identity evidence. | evidence-engineering, missingness, source-aware, provenance, interpretable, conflicting, uncertainty |

### 07 — Matching & Scoring

[Domain map](taxonomy/domains/07-matching-scoring.md)

| ID / title | Type | Domain | L1 discovery summary | Tags |
|---|---|---|---|---|
| [DEC-07-001 — How should candidate pairs be scored?](decisions/scoring-strategy.md) | decision | 07 | Compare expert-weighted additive evidence, Fellegi–Sunter likelihood ratios, and supervised logistic regression without treating them as a mandatory progression. Choose using identity semantics, candidate selection, evidence dependencies, label representativeness, interpretability, and downstream losses. Distinguish ranking scores from probabilities and scoring from decision policy. Reliable identifiers may justify simpler rules; limited labels do not remove statistical assumptions. Controlled comparisons must hold candidate generation and evaluation populations explicit. | entity-agnostic, interpretable, pairwise, calibration, few-labels, asymmetric-costs, evaluation |
| [HYP-07-001 — Context-dependent attribute reliability without circular supervision](research/hypotheses/contextual-reliability.md) | hypothesis | 07 | Test whether constrained source- and time-aware evidence weighting reduces held-out decision cost relative to a pooled scorer with the same candidates and comparisons. The proposal is untested: contextual likelihoods motivate it, but sparse source pairs, label bias, circular reliability estimates, and population shifts can defeat it. Independent adjudication, hierarchical shrinkage, entity-disjoint and temporal holdouts, and predeclared precision and compute guardrails are prerequisites. Context is a conditional evidence model, not a universal ranking of trustworthy sources. | experimentation, source-aware, evidence-engineering, pairwise, interpretable, asymmetric-costs, uncertainty, entity-agnostic |
| [SOL-07-001 — Additive soft matching](solutions/matching-scoring/additive-soft-matching.md) | solution | 07 | Combine explicit comparison features through a baseline and signed evidence contributions rather than requiring every field to agree. Expert weights provide a transparent reference specification; likelihood-ratio estimation or supervised fitting can replace manual weights while retaining an additive structure. Feature semantics, candidate conditioning, and conflicting evidence require deliberate treatment. A raw additive score is neither necessarily a probability nor a calibrated confidence, and learned or nonlinear variants are alternatives rather than mandatory upgrades. | entity-agnostic, no-labels, few-labels, interpretable, pairwise, evidence-engineering, missingness, low-cost |
| [SOL-07-002 — Fellegi–Sunter evidence weighting](solutions/matching-scoring/fellegi-sunter.md) | solution | 07 | Compare the distribution of observed comparison evidence among true matches with its distribution among non-matches. The joint likelihood ratio is the theoretical foundation; additive field weights require conditional independence within both classes. State-specific probabilities may be estimated from labels or a constrained mixture model, but unlabeled estimation is not assumption-free. Candidate conditioning, prior odds, dependency, and estimation uncertainty determine whether likelihood-ratio scores can support credible posterior probabilities and operational decisions. | entity-agnostic, no-labels, few-labels, interpretable, pairwise, blocking, missingness, calibration, uncertainty |
| [SOL-07-003 — Logistic regression for pairwise matching](solutions/matching-scoring/logistic-regression.md) | solution | 07 | Learn an interpretable conditional log-odds function from labeled comparison evidence and map it through the logistic link. Predictor independence is not required, but correlated features can destabilize individual coefficients and a restricted feature basis can miss interactions. Representative labels, candidate-population alignment, leakage-safe assessment, and calibration checks are central prerequisites. Regularization, constrained fitting, and richer additive functions are optional variants, not an inevitable progression beyond simpler expert or likelihood-ratio scoring. | entity-agnostic, few-labels, rich-labels, interpretable, pairwise, calibration, source-aware, evaluation |

### 08 — Decision Policies & Entity Resolution

[Domain map](taxonomy/domains/08-decision-resolution.md)

| ID / title | Type | Domain | L1 discovery summary | Tags |
|---|---|---|---|---|
| [SOL-08-001 — Thresholds, abstention, and review policies](solutions/decision-resolution/thresholds-abstention.md) | solution | 08 | Convert pairwise scores into link, non-link, or deferred decisions using explicit losses, validated operating points, and review constraints. A probability-based cost threshold is justified only for calibrated estimates in the stated decision population with specified pairwise losses. Review is an action with cost, delay, and residual error, not a free confidence band. Semantic vetoes require genuine incompatibility. Assignment and clustering may need global resolution rather than independent thresholding. | entity-agnostic, pairwise, asymmetric-costs, high-precision, human-review, uncertainty, assignment, clustering |

### 09 — Master Entity Construction & Maintenance

[Domain map](taxonomy/domains/09-master-maintenance.md)

Taxonomy coverage only; no standalone pilot cards. See [expansion plan](guides/expansion-plan.md).

### 10 — Ground Truth & Labeling

[Domain map](taxonomy/domains/10-ground-truth.md)

Taxonomy coverage only; no standalone pilot cards. See [expansion plan](guides/expansion-plan.md).

### 11 — Evaluation & Diagnostics

[Domain map](taxonomy/domains/11-evaluation-diagnostics.md)

| ID / title | Type | Domain | L1 discovery summary | Tags |
|---|---|---|---|---|
| [EVAL-11-001 — Candidate recall and retrieval efficiency](evaluation/candidate-recall.md) | evaluation | 11 | Measure whether candidate generation retains independently established true matches while reducing eligible comparisons. This evaluation separates retrieval completeness from conditional scoring recall and final entity quality, and compares complementary passes through deduplicated marginal yield. It requires an explicit pairspace, independently assembled reference matches, and a defensible sampling design. Budget limits, incomplete labels, population shifts, and entity dependence can invalidate apparently strong results; cost and segment diagnostics therefore accompany aggregate recall. | evaluation, candidate-generation, blocking, multi-pass, high-recall, uncertainty, entity-agnostic |
| [EVAL-11-002 — Pairwise discrimination and probability calibration](evaluation/pairwise-calibration.md) | evaluation | 11 | Evaluate pairwise ranking, threshold decisions, and the reliability of claimed match probabilities as separate properties. The protocol requires held-out labels, a declared candidate-conditioned or population estimand, and sampling weights where review selection changes prevalence. Precision–recall curves, proper probability scores, reliability diagrams, and cost diagnostics support comparison without treating arbitrary evidence scores as probabilities. Entity dependence, selective labels, changing retrieval, and downstream constraints limit interpretation; final entity quality needs its own evaluation. | evaluation, pairwise, calibration, uncertainty, asymmetric-costs, entity-agnostic |
| [EVAL-11-003 — Final entity-resolution quality and error diagnostics](evaluation/entity-resolution-quality.md) | evaluation | 11 | Assess the final identity output rather than assuming pairwise scores determine entity quality. Complete reference partitions support cluster-induced pair precision/recall and record-averaged B-cubed metrics; sampled fully resolved entities require design-aware estimation instead of naive benchmark slicing. Overmerge, undermerge, assignment, and catastrophic-error diagnostics connect measurements to application costs. Reference completeness, dependent records, output semantics, and oracle label support are essential prerequisites. The protocol offers complementary views, not one universally optimal metric. | evaluation, clustering, assignment, constraints, collective, uncertainty, asymmetric-costs, entity-agnostic |

### 12 — Experimentation & Research Methods

[Domain map](taxonomy/domains/12-experimentation.md)

Taxonomy coverage only; no standalone pilot cards. See [expansion plan](guides/expansion-plan.md).

### 13 — Scalability & Execution

[Domain map](taxonomy/domains/13-scalability-execution.md)

Taxonomy coverage only; no standalone pilot cards. See [expansion plan](guides/expansion-plan.md).

### 14 — Explainability, Governance & Monitoring

[Domain map](taxonomy/domains/14-governance-monitoring.md)

Taxonomy coverage only; no standalone pilot cards. See [expansion plan](guides/expansion-plan.md).

## Coverage and evidence

The catalog indexes completed objects, not every method mentioned in the fourteen domain maps. Unexpanded families remain in [research opportunities](research/opportunities-index.md) and the [expansion plan](guides/expansion-plan.md). Maturity and evidence are separate metadata fields; hypotheses have no observed Atlas outcomes. Source-specific support and its limitations appear in each card.

Generated from frontmatter by `python tools/atlas_docs.py catalog`. Maintain the cards and regenerate this index rather than editing derived summaries independently.
