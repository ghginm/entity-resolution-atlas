# Pilot quality review

## Review scope
This review separates documentation integrity, scientific/experimental content and conceptual usefulness. Passing tooling does not prove ER performance. No matching implementation, data processing, training or empirical ER benchmark was produced.

## Conceptual and research checks
- Distinguish likelihood-ratio foundations from the conditional-independence additive simplification; avoid automatically calibrated expert scores or probabilities without compatible priors/populations.
- Distinguish candidate conditioning, label sampling, within-pair feature dependence, cross-pair record dependence and global constraints.
- Review missing/invalid/contradiction evidence, identity namespace/time semantics, double counting and shared-attribute collisions.
- Keep score estimation, risk/abstention actions, membership consistency and consumer master representation separate.
- Check candidate union monotonicity conditions, clipping/skew costs, early-exit errors, correlated ensemble signals, unmatched assignment options, feedback and incremental dependency closure.
- Verify hypotheses are untested, controlled and falsifiable, with application-specific effect thresholds/guardrails selected before testing; low power remains inconclusive.
- Match metrics to candidate, pairwise, entity and end-to-end outputs; incomplete truth does not authorize unknown-negative labels, naive partial-cluster metrics or population-wide oracle ceilings.

## Tooling scope
The [documentation checker](../tools/README.md) checks YAML, ID/type/domain/tag validity, typed relationships, paths/anchors, approved citations, immutable source hashes, pilot counts and catalog freshness. Its unit tests exercise both success and deliberate-invalid cases. External-source claim support additionally requires source-aware review, not just valid citation numbers.

## Scenario assessment
The [three conceptual stress tests](scenario-stress-tests.md) compare baseline and alternative compositions under clean structured, noisy multilingual and large heterogeneous assumptions. They explicitly expose gaps and do not supply hypothetical performance numbers. Every scenario offers layered evaluation and conditional research opportunities rather than one universal architecture.

## Remaining limitations
Pilot depth concentrates on candidate generation, comparison states and interpretable soft scoring. Language-specific normalization, approximate/learned retrieval, label acquisition, global-resolution algorithms, master maintenance, distributed/streaming execution and privacy remain taxonomy/architecture guidance or planned work. Architecture contracts are not implementation or security guarantees. Numeric experiment criteria require a real application; no local ER results validate them. One collective reference has publisher-abstract support only, and failed exploratory URLs are excluded.

## Executed verification results
- **Nineteen documentation-tool unit tests passed**, including intentional invalid metadata, links, input modification, citation failures and reciprocal relations.
- Full repository lint returned **zero errors and zero warnings**. Verified counts: fourteen domains, six architectures, three decisions, seven solutions, two hypotheses, three evaluations and five templates.
- All twenty-one object IDs and typed targets resolve. The catalog matches current frontmatter, and relative Markdown paths/heading anchors resolve.
- Citation rendering and ledger verification passed for **twenty-three documents**: all cards, the deep dive and bibliography. Shared-ledger unused-source notices are expected per document, not missing-source failures; failed exploratory references are forbidden by the repository checker.
- All six historical input hashes and their original inventory match. No source bytes were altered.
- Every scenario has two explicit alternative configurations, at least two linked architecture patterns, all three evaluation routes and both hypothesis routes. These are documented conceptual checks, not measured performance.
- Discovery summaries span 64–76 words. Card bodies meet the standard depth range. Inline/display math delimiters are paired in the five equation-bearing documents.

Machine-readable scope and results: [validation-results.json](validation-results.json). Commands and checker limits: [tools](../tools/README.md).

## Integration problems identified and corrected
1. Removed four redundant reciprocal metadata pairs across hypotheses/evaluations, retaining inferred reverse navigation; added a regression test.
2. Fixed the checker to distinguish numeric domain-navigation labels from bibliography citations; added two regression tests rather than hiding valid domain links.
3. Added direct architecture/evaluation/hypothesis retrieval links to scenarios B/C so each scenario is usable independently.
4. Clarified statistical probability resolution versus entity-membership resolution, and strictly monotone recalibration versus maps that introduce score ties.
5. Standardized math to GitHub-flavored `$`/`$$` delimiters and refreshed source blocks from verified ledger metadata.
6. Excluded unverified/failed exploratory URLs and removed unverified bibliographic metadata; preserved the explicit publisher-abstract-only limitation.

## Initial acceptance gate
The foundation and bounded pilot meet the requested structural and conceptual gate: coherent fourteen-domain ownership; independent architecture axes; six composable archetypes; five templates; fifteen additional meaningful pilot cards; mechanisms/prerequisites/failures; falsifiable hypotheses; supported or qualified claims; valid cross-references; selective catalog and agent workflow; three conceptual scenario tests; a grouped expansion plan; and unchanged historical inputs.

This gate is not a claim of exhaustive ER coverage, empirical method validation or universal architecture superiority. Further expansion requires user review of [priorities and feedback questions](expansion-plan.md).
