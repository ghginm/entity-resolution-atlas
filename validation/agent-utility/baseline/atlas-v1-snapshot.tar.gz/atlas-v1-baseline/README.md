# Entity Resolution Solution Atlas

A project-agnostic, Markdown-first knowledge base for deciding how to design, evaluate and improve Entity Resolution systems. It expands alternatives rather than prescribing one architecture.

**This is not an ER implementation.** There are no matching algorithms, trained models, processed datasets or production application here. Documentation validation tools check the knowledge repository only.

## Start with a question
1. Record the actual project's identity semantics, sources, label availability, data quality, error costs, access constraints and lifecycle in [project intake](guides/project-intake.md).
2. Use [CATALOG.md](CATALOG.md) to retrieve by domain or problem characteristics; read relevant Decision Cards rather than the entire repository.
3. Compare a simple baseline and applicable alternatives; inspect [architecture dimensions](taxonomy/architecture-dimensions.md) and [module contracts](taxonomy/module-contracts.md).
4. Use hypotheses and evaluations to propose a falsifiable project-specific experiment. Do not treat a theoretical mechanism as a measured improvement.

For future agents, [AGENTS.md](AGENTS.md) defines selective retrieval and uncertainty-preserving recommendations.

## Navigation
| Location | Purpose |
|---|---|
| [Taxonomy](taxonomy/overview.md) | Fourteen coherent knowledge domains and boundaries |
| [Catalog](CATALOG.md) | IDs, types, summaries, applicability tags and direct card links |
| `decisions/` | Candidate, comparison-evidence and scorer selection questions |
| `solutions/` | Blocking, evidence states, interpretable soft scoring and decision policies |
| `architectures/` | Six reusable, composable reference patterns |
| `research/hypotheses/` | Untested frequency and contextual-reliability experiments |
| `evaluation/` | Candidate, pairwise/calibration and entity-level evaluation |
| [Guides](guides/project-intake.md) | Intake, comparisons, conceptual scenario tests and expansion |
| [Deep dive](deep-dives/selection-and-calibration.md) | Selection bias, dependence and probability interpretation |
| `templates/` | The five primary card formats |
| [References](references/bibliography.md) | Verified sources, evidence scope and immutable-input hashes |
| `dev_docs/` | Six historical design discussions, unchanged |
| `tools/` | Optional documentation lint/catalog tooling, not ER code |

## Pilot scope and quality gate
The completed initial pilot contains **six Architecture Cards plus fifteen non-architecture pilot cards**: three decisions, seven solutions, two hypotheses and three evaluations. Architecture supplies the fifth object type. L1 discovery summaries support cheap navigation, L2 cards explain mechanisms and failures, and a single justified L3 deep dive avoids needless duplication.

All fourteen domains have maps, but most method families outside candidate/evidence/interpretable scoring remain unexpanded. Taxonomy mentions are not completed Solution Cards. [Reconciliation](guides/design-reconciliation.md) explains changes from the drafts; [opportunities](research/opportunities-index.md) preserves useful unexpanded ideas.

The [three scenario stress tests](guides/scenario-stress-tests.md) are conceptual usefulness checks, **not empirical benchmarks**. See [quality review](guides/quality-review.md) for verified checks and limitations. Stop at this pilot for user review; [expansion plan](guides/expansion-plan.md) is a sequencing proposal, not authorization to mass-generate the encyclopedia.

## Evidence and contribution rules
- Follow [SCHEMA.md](SCHEMA.md) and the [evidence policy](references/evidence-policy.md).
- Preserve source bytes, stable IDs and one canonical location per object.
- Cite checked literature, specify its context, and label hypotheses/unknowns explicitly.
- Distinguish score semantics, decision actions and entity representations.
- Maintain the catalog, typed relations and [change log](guides/change-log.md).
- Run documented [repository checks](tools/README.md) and perform conceptual review before declaring coverage complete.

This Atlas is a knowledge resource, not an instruction to change a production system. No reference pattern is universally optimal.
