# Knowledge conventions

## Scope and precedence
This repository is a decision-support Atlas, not an ER implementation. The supplied Master Instruction takes precedence over the six immutable historical files in `dev_docs/`; external evidence and explicitly labeled reasoning refine their content. Guides, taxonomy pages, design notes and deep dives are supporting documents, not extra knowledge-object types.

## Identity and classification
- IDs are permanent: `DEC-DD-NNN`, `SOL-DD-NNN`, `HYP-DD-NNN`, `EVAL-DD-NNN`, where DD is the two-digit primary domain. Architecture IDs are **AR-01 through AR-06**, preserving the requested archetype names; do not create parallel ARC aliases.
- Five types: `decision`, `solution`, `architecture`, `hypothesis`, `evaluation`. Domain is a quoted two-digit string, `"01"` through `"14"`. Architectures primarily belong to `"02"`; evaluations to `"11"`.
- One canonical location per object. Do not reuse an ID after deletion. Rename paths only with all links updated; the ID remains unchanged.
- Card frontmatter requires `id`, `type`, `title`, `domain`, `summary`, `tags`, `maturity`, `evidence`, and `relations`. Summary is an L1 discovery description of approximately 50–100 words, not an experimental outcome. Catalog repeats it for selective retrieval.
- Maturity: `established`, `context-dependent`, `experimental`, `speculative`.
- Evidence (independent of maturity): `theoretically-motivated`, `supported-by-external-literature`, `empirically-validated-in-specific-context`, `unknown-or-insufficient`. No Atlas experiment has been run. Source-specific validation is described with its population, design and limitations, never treated as a universal win.

## Typed relation directions
Frontmatter `relations` is a mapping of relation names to lists of existing card IDs:
- `addresses`: solution → design decision.
- `alternative_to`: materially substitutable objects, not merely related topics.
- `complements`: useful joint use, explain the interaction in prose.
- `requires`: a necessary prerequisite object, not a preferred baseline.
- `conflicts_with`: an explicit conditional incompatibility, explain its condition.
- `used_by`: component → architecture (not architecture → component).
- `tests`: hypothesis/evaluation → tested solution or architecture.
- `evaluated_by`: decision/solution/architecture/hypothesis → evaluation.
Store one direction; reverse relationships can be inferred. Explain non-obvious relations in the body. Minimum two typed outbound relationships per substantive card; exceptions require an explicit reason. Body references use ordinary relative Markdown links, never bare IDs alone as a substitute for navigation. All referenced IDs, paths and headings must resolve.

## Depth and evidence
L1 is the discovery summary; L2 is usually 400–900 words of substantive card body; L3 is optional advanced material. Mechanism, assumptions, failure modes, evaluation and meaningful alternatives are required, not token headings. Mathematical consequences must state their assumptions. Proposed performance improvements are hypotheses unless source-specific measurements are actually cited. Derived examples are illustrative, never measured results.

Use `$...$` for inline math and separate `$$` lines for display equations, compatible with GitHub-flavored Markdown math. Keep equations substantive and define their quantities.

External-source claims use ledger-issued `[n]` citations and a mechanically rendered Sources block per document. The shared ledger is `references/source-ledger.json`; [reference policy](references/evidence-policy.md) governs support. Do not invent bibliography metadata, empirical findings or URLs. Cite primary literature or author-maintained documentation; mark unavailable verification explicitly.

## Controlled applicability tags
- Labels: `no-labels`, `few-labels`, `rich-labels`.
- Quality: `clean`, `noisy`, `sparse`, `conflicting`.
- Scale/compute: `small-scale`, `large-scale`, `low-cost`, `compute-intensive`.
- Entities: `person`, `organization`, `address`, `identifiers`, `entity-agnostic`.
- Language: `monolingual`, `multilingual`, `multiscript`.
- Objectives: `high-precision`, `high-recall`, `asymmetric-costs`.
- Interpretation: `interpretable`, `calibration`, `uncertainty`.
- Lifecycle: `batch`, `incremental`, `streaming`, `federated`.
- Technical retrieval: `candidate-generation`, `blocking`, `multi-pass`, `evidence-engineering`, `missingness`, `frequency-aware`, `source-aware`, `pairwise`, `assignment`, `clustering`, `collective`, `constraints`, `provenance`, `human-review`, `evaluation`, `experimentation`, `governance`, `privacy`, `monitoring`.
Tags aid discovery, not proof of applicability. Add a new tag here before use. Do not assign universal research priority.

## Change and validation workflow
Preserve `dev_docs/` bytes; baseline hashes are in `references/dev-docs-sha256.json`. Update `CATALOG.md` when adding/removing a card. Add a concise entry to `guides/change-log.md`. Validate structure, links, IDs, sources, templates, pilot counts, and immutable files; then perform conceptual review. Documentation checks do not validate ER performance. Stop after the initial pilot and expansion plan for user review; do not mass-generate remaining cards.
