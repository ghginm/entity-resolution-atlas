# Agent instructions: consuming and maintaining the Atlas

## Scope and authority
This is a project-agnostic knowledge repository, not an ER implementation or autonomous instruction to change production. User project facts and permissions govern any future implementation outside the Atlas. The Master Instruction supplied for this initial build outranks iterative historical drafts. [SCHEMA](SCHEMA.md) defines local metadata and relations; [evidence policy](references/evidence-policy.md) defines support.

## Selective consumption workflow
1. Understand the real project's requirements **and current implementation** before choosing Atlas methods. Use [project intake](guides/project-intake.md); identify missing identity semantics, source namespaces, labels, temporal assumptions, error costs, privacy/access, compute and downstream constraints. Do not fabricate any of them.
2. Identify relevant design decisions. Distinguish retrieval loss, evidence insufficiency, scorer errors, policy errors, inconsistent membership and incorrect master attributes.
3. Search [compact catalog](CATALOG.md) by primary domain and problem-characteristic tags. Read only the relevant domain summaries when ownership is unclear. **Do not read the entire repository or all dev_docs by default.**
4. Read applicable Decision Cards; retrieve their linked Solutions and Architecture Cards. If only taxonomy coverage exists, state the gap rather than inventing a detailed method card.
5. Inspect hard prerequisites, optional context, incompatibilities and cross-module interactions. A similar method name or tag does not prove applicability.
6. Compare at least one simple credible baseline with plausible alternatives. Preserve the four independent [architecture dimensions](taxonomy/architecture-dimensions.md); AR patterns are composable references, not mandatory implementation blueprints.
7. Retrieve relevant Hypothesis and Evaluation Cards. Prefer a controlled experiment that distinguishes mechanisms to unsupported confidence in a complex method.
8. Produce a project-specific experiment or implementation plan with explicit assumptions, uncertainty, data needs and authorization requirements. The Atlas alone never authorizes changing another repository or production data.

## Required recommendation output
- Known project facts versus missing information/assumptions.
- Relevant decision IDs and why each matters.
- Baseline and at least one alternative, with mechanisms, prerequisites, costs and failure modes.
- Candidate configurations with topology/scoring/resolution/lifecycle choices and module contracts.
- Proposed experiment: comparator, controls, split/labels, metrics, uncertainty, practical success/falsification criteria and guardrails.
- Next decision after positive, negative or inconclusive evidence.

## Rules against misleading recommendations
Do not recommend something merely because it exists here. Do not automatically prefer newer, neural or more complex methods. Consider actual data quality, label representativeness, runtime cost and asymmetric error costs. Keep theory, externally observed evidence and untested hypotheses distinct. Never invent experimental results, paper metadata or project facts. A raw additive score is not necessarily a probability; calibrated pair probabilities are not automatically cluster confidence. Candidate changes may invalidate calibration; missing edges are not non-match labels. Review performance on relevant source/language/population slices and final entities, not only aggregate pair metrics. Avoid irreversible decisions when information is inadequate.

## Retrieval examples
- Few labels + noisy names + costly false merges: candidate/evidence decisions → additive/FS alternatives → thresholds/abstention → candidate and pair/entity evaluation → contextual/frequency hypotheses.
- Reliable structured identifiers: audit namespace/validity → exact blocking/simple rule baseline → ambiguity policy; complex collective inference is optional.
- Updates and deletion: AR-06 plus the selected retrieval/scoring pattern → dependency closure, reversible membership and stable IDs → replay/quality/cost diagnostics.

## Maintaining this repository
Keep `dev_docs/` immutable; verify against its hashes. Add objects through one of the five [templates](templates/solution.md), respecting [ownership](taxonomy/overview.md), stable IDs, approved tags and correctly directed relations. Cite verified ledger IDs and mechanically render Sources blocks. Update catalog and change log. Run [documentation checks](tools/README.md), then inspect conceptual quality; lint cannot prove scientific accuracy. Do not create new ER algorithms, process datasets or train models here. Do not expand beyond the validated initial pilot without user review of [expansion priorities](guides/expansion-plan.md).
